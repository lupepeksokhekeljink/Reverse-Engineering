# DECODED FROM: scanwebbwolf.py
# DECODE TIME: 2025-12-13 11:25:27.904075
# Deobfuscate By AndraxC2 Auto Decode
# Method: PyObfuscate.com AES Decoder

import base64
import requests
import socket
import ssl
import whois
import dns.resolver
from datetime import datetime
import urllib.parse
import time
import concurrent.futures
import os
import platform
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.live import Live
from rich.panel import Panel
from rich.style import Style
import pyfiglet

COLORS = {
    'primary': 'deep_sky_blue2',
    'secondary': 'slate_blue3',
    'success': 'green3',
    'warning': 'yellow3',
    'error': 'red3',
    'info': 'cyan2',
    'text': 'white',
    'highlight': 'grey84',
    'banner': 'bright_blue'
}

console = Console()

def clean_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def clean_url(url):
    url = url.strip().lower()
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    return url

def get_domain(url):
    parsed = urllib.parse.urlparse(url)
    return parsed.netloc

def format_date(date_str):
    if not date_str:
        return "Not Available"
    try:
        if isinstance(date_str, str):
            try:
                date_obj = datetime.strptime(date_str, "%b %d %H:%M:%S %Y GMT")
            except:
                try:
                    date_obj = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                except:
                    return str(date_str)
        else:
            date_obj = date_str
        return date_obj.strftime("%d %B %Y")
    except Exception:
        return str(date_str)

def get_security_headers(headers):
    security_headers = {
        'Strict-Transport-Security': 'HSTS',
        'Content-Security-Policy': 'CSP',
        'X-Frame-Options': 'X-Frame',
        'X-Content-Type-Options': 'X-Content-Type',
        'X-XSS-Protection': 'XSS Protection',
        'Referrer-Policy': 'Referrer Policy',
        'Feature-Policy': 'Feature Policy',
        'Permissions-Policy': 'Permissions Policy'
    }
    return {new_name: headers.get(header, 'Not Available') 
            for header, new_name in security_headers.items()}

def check_admin_panel(url, timeout=3):
    admin_paths = [
        '/admin', '/administrator', '/wp-admin', '/login', 
        '/panel', '/admin.php', '/cp', '/admin/login',
        '/backend', '/manager', '/system', '/webadmin',
        '/cms', '/controlpanel', '/user', '/users'
    ]
    found_paths = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        def check_path(path):
            try:
                test_url = url.rstrip('/') + path
                response = requests.get(test_url, timeout=timeout, allow_redirects=False)
                if response.status_code in [200, 301, 302, 403, 401]:
                    title_match = None
                    if '<title>' in response.text.lower():
                        title_start = response.text.lower().find('<title>')
                        title_end = response.text.lower().find('</title>')
                        if title_start != -1 and title_end != -1:
                            title_match = response.text[title_start+7:title_end].strip()
                    
                    return {
                        'url': test_url,
                        'status': response.status_code,
                        'title': title_match[:50] + '...' if title_match and len(title_match) > 50 else title_match
                    }
            except:
                pass
            return None
        
        futures = [executor.submit(check_path, path) for path in admin_paths]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                found_paths.append(result)
    
    return found_paths

def grab_banner(url, timeout=5):
    try:
        response = requests.get(url, timeout=timeout)
        server = response.headers.get('Server', 'Not Available')
        x_powered_by = response.headers.get('X-Powered-By', 'Not Available')
        return server, x_powered_by
    except Exception as e:
        return f'Error: {str(e)}', 'Not Available'

def get_technologies(url):
    try:
        response = requests.get(url, timeout=10)
        technologies = []
        
        server = response.headers.get('Server', '')
        if server and server != 'Not Available':
            technologies.append(f"Server: {server}")
        
        powered_by = response.headers.get('X-Powered-By', '')
        if powered_by and powered_by != 'Not Available':
            technologies.append(f"Powered By: {powered_by}")
        
        content = response.text.lower()
        headers = str(response.headers).lower()
        
        if any(x in content or x in headers for x in ['wordpress', 'wp-content', 'wp-includes']):
            technologies.append("WordPress")
        
        if any(x in content or x in headers for x in ['drupal', 'drupal.settings']):
            technologies.append("Drupal")
        
        if any(x in content or x in headers for x in ['joomla', 'joomla.org']):
            technologies.append("Joomla")
        
        if 'laravel' in content or 'laravel' in headers:
            technologies.append("Laravel")
        
        if 'express' in headers or 'x-powered-by: express' in headers:
            technologies.append("Express.js")
        
        if 'asp.net' in headers or 'x-aspnet-version' in headers:
            technologies.append("ASP.NET")
        
        if 'php' in headers or '.php' in content:
            technologies.append("PHP")
        
        if 'nginx' in headers:
            technologies.append("Nginx")
        
        if 'apache' in headers:
            technologies.append("Apache")
        
        return ', '.join(technologies) if technologies else 'Not Detected'
    except Exception as e:
        return f"Error: {str(e)}"

def get_server_location(ip):
    try:
        response = requests.get(f"https://ipapi.co/{ip}/json/", timeout=10)
        data = response.json()
        city = data.get('city', 'Not Available')
        country = data.get('country_name', 'Not Available')
        return city, country
    except:
        return "Not Available", "Not Available"

def get_ip_info(domain):
    try:
        ip = socket.gethostbyname(domain)
        
        try:
            response = requests.get(f"https://ipapi.co/{ip}/json/", timeout=10)
            ip_data = response.json()
            org = ip_data.get('org', 'Not Available')
            asn = ip_data.get('asn', 'Not Available')
        except:
            org = 'Not Available'
            asn = 'Not Available'
        
        return ip, org, asn
    except Exception as e:
        return f"Error: {str(e)}", "Not Available", "Not Available"

def create_styled_table(title):
    table = Table(
        title=title,
        title_style=Style(color=COLORS['primary'], bold=True),
        border_style=Style(color=COLORS['secondary']),
        header_style=Style(color=COLORS['highlight'], bold=True),
        pad_edge=False,
        expand=True,
        show_lines=True
    )
    table.add_column("Category", style=Style(color=COLORS['info'], bold=True), no_wrap=True)
    table.add_column("Details", style=Style(color=COLORS['text']))
    return table

def display_banner():
    banner_ascii = """
                   ⢀⣀⣀⣀⣀      
                ⣀⣴⣾⣿⣿⣿⣿⣿⣿⣶⣄   
              ⣠⣾⣿⣿⣿⣿⣿⠿⢿⣿⣿⣿⣿⣆  
            ⢀⣴⣿⣿⣿⣿⣿⣿⠁ ⠿⢿⣿⡿⣿⣿⡆ 
          ⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣦⣤⣴⣿⠃ ⠿⣿⡇ 
        ⣠⣾⣿⣿⣿⣿⣿⣿⡿⠋⠁⣿⠟⣿⣿⢿⣧⣤⣴⣿⡇ 
    ⢀⣠⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷    ⠘⠁⢸⠟⢻⣿⡿  
  ⠙⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣴⣇⢀⣤    ⠘⣿⠃  
     ⢈⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣴⣿⢀⣴⣾⠇   
  ⣀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏    
  ⠉⠉⠉⠉⣡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃     
    ⣠⣾⣿⣿⣿⣿⡿⠟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁      
  ⣴⡾⠿⠿⠿⠿⠛⠋⠁ ⢸⣿⣿⣿⣿⠿⠋⢸⣿⡿⠋       
            ⢠⣿⡿⠟⠋⠁  ⡿⠋        
            ⠈⠁                
"""
    
    console.print(Panel(
        f"[{COLORS['banner']}]{banner_ascii}[/{COLORS['banner']}]\n"
        f"[{COLORS['primary']}]{' ' * 15}SCANWEB WOLF[/{COLORS['primary']}]\n"
        f"[{COLORS['secondary']}]{' ' * 18}AUTHOR : H0Xcysec : github : https://github.com/H0Xcysecom[/{COLORS['secondary']}]",
        border_style=Style(color=COLORS['primary']),
        padding=(1, 2)
    ))

def scan_website(url):
    try:
        start_time = time.time()
        url = clean_url(url)
        domain = get_domain(url)
        
        with Progress(
            SpinnerColumn(style=COLORS['primary']),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(complete_style=COLORS['success'], finished_style=COLORS['success']),
            TimeElapsedColumn(),
            console=console,
            expand=True
        ) as progress:
            main_table = create_styled_table(f"🔍 Website Scan Results: {url}")
            scan_task = progress.add_task(
                f"[{COLORS['info']}]Initializing scan...",
                total=100
            )
            
            
            progress.update(scan_task, advance=5, 
                          description=f"[{COLORS['info']}]Resolving IP and DNS...")
            try:
                ip, org, asn = get_ip_info(domain)
                main_table.add_row("IP Address", ip)
                main_table.add_row("Organization", org)
                main_table.add_row("ASN", asn)
                
                try:
                    a_records = dns.resolver.resolve(domain, 'A')
                    mx_records = dns.resolver.resolve(domain, 'MX')
                    
                    dns_info = []
                    dns_info.append("A Records:")
                    for record in a_records:
                        dns_info.append(f"  {record.address}")
                    
                    dns_info.append("\nMX Records:")
                    for record in mx_records:
                        dns_info.append(f"  {record.exchange} (Priority: {record.preference})")
                    
                    main_table.add_row("DNS Information", "\n".join(dns_info))
                except Exception as e:
                    main_table.add_row("DNS Information", f"Limited: {str(e)}")
                    
            except Exception as e:
                main_table.add_row("Network Info", f"Error: {str(e)}")

            # Check SSL certificate
            progress.update(scan_task, advance=15, 
                          description=f"[{COLORS['info']}]Checking SSL certificate...")
            try:
                context = ssl.create_default_context()
                with socket.create_connection((domain, 443), timeout=10) as sock:
                    with context.wrap_socket(sock, server_hostname=domain) as ssock:
                        cert = ssock.getpeercert()
                        main_table.add_row("SSL Valid From", format_date(cert['notBefore']))
                        main_table.add_row("SSL Valid Until", format_date(cert['notAfter']))
                        main_table.add_row("SSL Issuer", cert.get('issuer', [[('', 'Not Available')]])[0][0][1])
            except Exception as e:
                main_table.add_row("SSL Status", f"Error: {str(e)}")

          
            progress.update(scan_task, advance=20, 
                          description=f"[{COLORS['info']}]Analyzing HTTP headers...")
            try:
                response = requests.get(url, timeout=10, headers={'User-Agent': 'Xscanweb-Security-Scanner/1.0'})
                status_color = COLORS['success'] if response.status_code == 200 else COLORS['warning']
                main_table.add_row(
                    "HTTP Status",
                    f"[{status_color}]{response.status_code} ({response.reason})[/{status_color}]"
                )

                security_headers = get_security_headers(response.headers)
                for header, value in security_headers.items():
                    color = COLORS['success'] if value != 'Not Available' else COLORS['warning']
                    main_table.add_row(header, f"[{color}]{value}[/{color}]")

            except Exception as e:
                main_table.add_row("HTTP Analysis", f"Error: {str(e)}")

            
            progress.update(scan_task, advance=15, 
                          description=f"[{COLORS['info']}]Fetching WHOIS data...")
            try:
                domain_info = whois.whois(domain)
                if domain_info.creation_date:
                    creation_date = domain_info.creation_date[0] if isinstance(domain_info.creation_date, list) else domain_info.creation_date
                    main_table.add_row("Domain Created", format_date(creation_date))
                if domain_info.expiration_date:
                    expiration_date = domain_info.expiration_date[0] if isinstance(domain_info.expiration_date, list) else domain_info.expiration_date
                    main_table.add_row("Domain Expires", format_date(expiration_date))
                if domain_info.registrar:
                    main_table.add_row("Registrar", domain_info.registrar)
            except Exception as e:
                main_table.add_row("WHOIS Info", f"Error: {str(e)}")

            
            progress.update(scan_task, advance=10, 
                          description=f"[{COLORS['info']}]Scanning for admin panels...")
            admin_panels = check_admin_panel(url)
            if admin_panels:
                panel_info = []
                for panel in admin_panels:
                    status_color = COLORS['success'] if panel['status'] == 200 else COLORS['warning']
                    panel_info.append(
                        f"[{status_color}]{panel['url']} (Status: {panel['status']})"
                        f"{' - ' + panel['title'] if panel.get('title') else ''}[/{status_color}]"
                    )
                main_table.add_row("Admin Panels Found", "\n".join(panel_info))
            else:
                main_table.add_row("Admin Panels", "[green]No common admin panels found[/green]")

            
            progress.update(scan_task, advance=10, 
                          description=f"[{COLORS['info']}]Gathering server information...")
            server, x_powered_by = grab_banner(url)
            main_table.add_row("Server Banner", server)
            main_table.add_row("X-Powered-By", x_powered_by)
            
            
            progress.update(scan_task, advance=10, 
                          description=f"[{COLORS['info']}]Detecting technologies...")
            technologies = get_technologies(url)
            main_table.add_row("Technologies Detected", technologies)

            
            progress.update(scan_task, advance=10, 
                          description=f"[{COLORS['info']}]Locating server...")
            try:
                ip_address = socket.gethostbyname(domain)
                city, country = get_server_location(ip_address)
                main_table.add_row("Server Location", f"{city}, {country}")
            except:
                main_table.add_row("Server Location", "Not Available")

            
            progress.update(scan_task, completed=100, 
                          description=f"[{COLORS['success']}]Scan completed successfully!")

        
        console.print(main_table)
        
      
        scan_time = time.time() - start_time
        console.print(Panel(
            f"[{COLORS['success']}]✓ Scan completed in {scan_time:.2f} seconds\n"
            f"[{COLORS['info']}]ℹ Total checks performed: 8 comprehensive security assessments\n"
            f"[{COLORS['primary']}]⭐ Thank you for using ScanWeb Wolf!",
            title="Scan Summary",
            border_style=Style(color=COLORS['success'])
        ))

    except Exception as e:
        console.print(Panel(f"Scan Error: {str(e)}", 
                          style=Style(color=COLORS['error']),
                          title="Error"))

if __name__ == "__main__":
    clean_screen()
    display_banner()
    
    try:
        console.print(f"\n[{COLORS['primary']}]💻 Enter website URL to scan (e.g., example.com):[/{COLORS['primary']}]")
        url_input = console.input(f"[{COLORS['info']}]>>> [/{COLORS['info']}]").strip()
        
        if not url_input:
            console.print(Panel("URL cannot be empty!", 
                              style=Style(color=COLORS['error'])))
        else:
            console.print(f"\n[{COLORS['secondary']}] Starting scan for: {url_input}[/{COLORS['secondary']}]\n")
            scan_website(url_input)
            
    except KeyboardInterrupt:
        console.print(Panel("\n  Scan canceled by user.", 
                          style=Style(color=COLORS['warning']),
                          title="Cancelled"))
    except Exception as e:
        console.print(Panel(f"Unexpected error: {str(e)}", 
                          style=Style(color=COLORS['error']),
                          title="Error"))
