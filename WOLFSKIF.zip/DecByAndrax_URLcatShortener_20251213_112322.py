# DECODED FROM: URLcatShortener.py
# DECODE TIME: 2025-12-13 11:23:33.911479
# Deobfuscate By AndraxC2 Auto Decode
# Method: PyObfuscate.com AES Decoder

import requests
import pyperclip
import sys
import time
import os
from urllib.parse import quote
from colorama import init, Fore, Style

init()

class URLShortener:
    def __init__(self):
        self.services = {
            '1': {'name': 'TinyURL', 'function': self.shorten_tinyurl},
            '2': {'name': 'is.gd', 'function': self.shorten_isgd},
            '3': {'name': 'v.gd', 'function': self.shorten_vgd},
            '4': {'name': 'da.gd', 'function': self.shorten_dagd},
        }
    
    def shorten_tinyurl(self, url):
        
        try:
            response = requests.get(f"https://tinyurl.com/api-create.php?url={quote(url)}", timeout=10)
            return response.text if response.status_code == 200 else f"Error: {response.status_code}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def shorten_isgd(self, url):
        
        try:
            response = requests.get(f"https://is.gd/create.php?format=simple&url={quote(url)}", timeout=10)
            return response.text if response.status_code == 200 else f"Error: {response.status_code}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def shorten_vgd(self, url):
        try:
            response = requests.get(f"https://v.gd/create.php?format=simple&url={quote(url)}", timeout=10)
            return response.text if response.status_code == 200 else f"Error: {response.status_code}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def shorten_dagd(self, url):
        
        try:
            response = requests.get(f"https://da.gd/s?url={quote(url)}", timeout=10)
            return response.text.strip() if response.status_code == 200 else f"Error: {response.status_code}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def display_menu(self):
        
        print(f"\n{Fore.GREEN}{'═'*60}{Style.RESET_ALL}")
        print(f"{Fore.GREEN}            ╔═══ URLCATSHORTENER ═══╗")
        print(f"{Fore.GREEN}            ║                        ║")
        print(f"{Fore.GREEN}            ║      PILIH LAYANAN     ║")
        print(f"{Fore.GREEN}            ╚════════════════════════╝")
        print(f"{Fore.GREEN}{'═'*60}{Style.RESET_ALL}")
        for key, service in self.services.items():
            print(f"{Fore.GREEN}║ {Fore.WHITE}{key}. {service['name']}")
        print(f"{Fore.GREEN}║ {Fore.WHITE}5. Semua Layanan (Bandwidth Test)")
        print(f"{Fore.GREEN}║ {Fore.WHITE}0. Keluar")
        print(f"{Fore.GREEN}{'═'*60}{Style.RESET_ALL}")
    
    def get_user_choice(self):
        
        while True:
            choice = input(f"{Fore.GREEN}╚═>{Fore.WHITE} Pilih layanan {Fore.GREEN}(0-5){Fore.WHITE}: {Style.RESET_ALL}").strip()
            if choice in ['0', '1', '2', '3', '4', '5']:
                return choice
            print(f"{Fore.GREEN}║ {Fore.WHITE}Pilihan tidak valid. Silakan pilih 0-5.{Style.RESET_ALL}")
    
    def shorten_url(self, url, service_key):
      
        if service_key == '5':  
            results = {}
            for key, service in self.services.items():
                print(f"\n{Fore.GREEN}╔═>{Fore.WHITE} Mencoba {service['name']}...{Style.RESET_ALL}")
                result = service['function'](url)
                results[service['name']] = result
                print(f"{Fore.GREEN}╚═>{Fore.WHITE} {service['name']}: {result}")
            return results
        else:
            service = self.services[service_key]
            print(f"\n{Fore.GREEN}╔═>{Fore.WHITE} Memproses dengan {service['name']}...{Style.RESET_ALL}")
            return service['function'](url)
    
    def copy_to_clipboard(self, text):
        
        try:
            pyperclip.copy(text)
            return True
        except:
            return False

def animate_text(text, delay=0.03):
    
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    
    os.system('cls' if os.name == 'nt' else 'clear')

def display_banner():
    
    clear_screen()
    print(f"{Fore.GREEN}")
    print("               ／＞　 フ                        AUTHOR : H0Xcysec")
    print("               | 　_　_|                        github : https://github.com/H0Xcysecom")
    print("          ／` ミ＿xノ ")
    print("         /　　　　 |")
    print("        /　 ヽ　　 ﾉ")
    print("        │　　|　|　|")
    print("／￣|　　 |　|　|")
    print("(￣ヽ＿_ヽ_)__)")
    print("＼二)")
    print(f"{Style.RESET_ALL}")
    print(f"{Fore.GREEN}{'═'*60}{Style.RESET_ALL}")
    animate_text(f"{Fore.WHITE}         URLCATSHORTENER", 0.05)
    print(f"{Fore.GREEN}{'═'*60}{Style.RESET_ALL}")

def main():
    display_banner()
    
    if len(sys.argv) > 1:
        url = sys.argv[1]
        print(f"{Fore.GREEN}╔═>{Fore.WHITE} URL terdeteksi: {url}{Style.RESET_ALL}")
    else:
        url = input(f"{Fore.GREEN}╔═>{Fore.WHITE} Masukkan URL yang akan diperpendek: {Style.RESET_ALL}").strip()
    
    if not url:
        print(f"{Fore.GREEN}║ {Fore.WHITE}URL gk boleh kosong bro!{Style.RESET_ALL}")
        return
    
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    shortener = URLShortener()
    
    while True:
        shortener.display_menu()
        choice = shortener.get_user_choice()
        
        if choice == '0':
            animate_text(f"{Fore.GREEN}╔═>{Fore.WHITE} Terima kasih udah menggunakan tools dari gw btw jangan lupa folow!{Style.RESET_ALL}", 0.03)
            break
        
        print(f"{Fore.GREEN}╔═>{Fore.WHITE} Memproses URL...{Style.RESET_ALL}")
        result = shortener.shorten_url(url, choice)
        
        if choice != '5':  
            service_name = shortener.services[choice]['name']
            print(f"\n{Fore.GREEN}╔═>{Fore.WHITE} Hasil dari {service_name}:{Style.RESET_ALL}")
            print(f"{Fore.GREEN}╚═>{Fore.WHITE} {result}{Style.RESET_ALL}")
            
            if not result.startswith("Error:"):
                copy = input(f"{Fore.GREEN}╔═>{Fore.WHITE} Salin ke clipboard? {Fore.GREEN}(y/n){Fore.WHITE}: {Style.RESET_ALL}").strip().lower()
                if copy == 'y':
                    if shortener.copy_to_clipboard(result):
                        print(f"{Fore.GREEN}╚═>{Fore.WHITE} ✓ Berhasil disalin ke clipboard!{Style.RESET_ALL}")
                    else:
                        print(f"{Fore.GREEN}╚═>{Fore.WHITE} ✗ Gagal menyalin ke clipboard.{Style.RESET_ALL}")
        
        continue_choice = input(f"\n{Fore.GREEN}╔═>{Fore.WHITE} Lanjutkan dengan URL yang sama? {Fore.GREEN}(y/n){Fore.WHITE}: {Style.RESET_ALL}").strip().lower()
        if continue_choice != 'y':
            animate_text(f"{Fore.GREEN}╔═>{Fore.WHITE} Terima kasih telah menggunakan URLcatShortener!{Style.RESET_ALL}", 0.03)
            break

if __name__ == "__main__":
    main()
