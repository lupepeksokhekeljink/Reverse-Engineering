const axios = require('axios');
const chalk = require('chalk');

async function getIpGeolocation(apiKey, ipAddress) {
  const apiUrl = `https://ipgeolocation.abstractapi.com/v1/?api_key=${apiKey}&ip_address=${ipAddress}`;
  
  try {
    const response = await axios.get(apiUrl);
    const data = response.data;
    
    if (data.ip_address) {
      const formattedData = {
        'ip_address': chalk.cyan(data.ip_address),
        'city': chalk.green(data.city || "Unknown"),
        'city_geoname_id': chalk.green(data.city_geoname_id || "Unknown"),
        'region': chalk.green(data.region || "Unknown"),
        'region_iso_code': chalk.green(data.region_iso_code || "Unknown"),
        'region_geoname_id': chalk.green(data.region_geoname_id || "Unknown"),
        'country': chalk.green(data.country || "Unknown"),
        'country_code': chalk.green(data.country_code || 'Unknown'),
        'country_geoname_id': chalk.green(data.country_geoname_id || "Unknown"),
        'country_is_eu': chalk.green(data.country_is_eu ? "Yes" : 'No'),
        'continent': chalk.green(data.continent || "Unknown"),
        'continent_code': chalk.green(data.continent_code || "Unknown"),
        'continent_geoname_id': chalk.green(data.continent_geoname_id || "Unknown"),
        'latitude': chalk.yellow(data.latitude || "Unknown"),
        'longitude': chalk.yellow(data.longitude || "Unknown"),
        'postal_code': chalk.green(data.postal_code || "Unknown"),
        'timezone_name': chalk.green(data.timezone.name || "Unknown"),
        'gmt_offset': chalk.green(data.timezone.gmt_offset || "Unknown"),
        'current_time': chalk.green(data.timezone.current_time || "Unknown"),
        'is_dst': chalk.green(data.timezone.is_dst ? "Yes" : 'No'),
        'is_vpn': chalk.green(data.security.is_vpn ? 'Yes' : 'No'),
        'currency_name': chalk.green(data.currency.currency_name || "Unknown"),
        'currency_code': chalk.green(data.currency.currency_code || "Unknown"),
        'connection': {
          'isp_name': chalk.cyan(data.connection.isp_name || "Unknown"),
          'organization_name': chalk.cyan(data.connection.organization_name || "Unknown"),
          'autonomous_system_number': chalk.cyan(data.connection.autonomous_system_number || 'Unknown'),
          'autonomous_system_organization': chalk.cyan(data.connection.autonomous_system_organization || "Unknown"),
          'connection_type': chalk.cyan(data.connection.connection_type || "Unknown")
        },
        'flag': {
          'emoji': chalk.magenta(data.flag.emoji || "Unknown"),
          'png': chalk.magenta(data.flag.png || "Unknown"),
          'svg': chalk.magenta(data.flag.svg || 'Unknown')
        }
      };

      // Display formatted results
      console.log('{');
      console.log(`  "ip_address": "${formattedData.ip_address}",`);
      console.log(`  "city": "${formattedData.city}",`);
      console.log(`  "city_geoname_id": "${formattedData.city_geoname_id}",`);
      console.log(`  "region": "${formattedData.region}",`);
      console.log(`  "region_iso_code": "${formattedData.region_iso_code}",`);
      console.log(`  "region_geoname_id": "${formattedData.region_geoname_id}",`);
      console.log(`  "country": "${formattedData.country}",`);
      console.log(`  "country_code": "${formattedData.country_code}",`);
      console.log(`  "country_geoname_id": "${formattedData.country_geoname_id}",`);
      console.log(`  "country_is_eu": "${formattedData.country_is_eu}",`);
      console.log(`  "continent": "${formattedData.continent}",`);
      console.log(`  "continent_code": "${formattedData.continent_code}",`);
      console.log(`  "continent_geoname_id": "${formattedData.continent_geoname_id}",`);
      console.log(`  "latitude": "${formattedData.latitude}",`);
      console.log(`  "longitude": "${formattedData.longitude}",`);
      console.log(`  "postal_code": "${formattedData.postal_code}",`);
      console.log(`  "timezone_name": "${formattedData.timezone_name}",`);
      console.log(`  "gmt_offset": "${formattedData.gmt_offset}",`);
      console.log(`  "current_time": "${formattedData.current_time}",`);
      console.log(`  "is_dst": "${formattedData.is_dst}",`);
      console.log(`  "is_vpn": "${formattedData.is_vpn}",`);
      console.log(`  "currency_name": "${formattedData.currency_name}",`);
      console.log(`  "currency_code": "${formattedData.currency_code}",`);
      console.log(`  "connection": {`);
      console.log(`    "isp_name": "${formattedData.connection.isp_name}",`);
      console.log(`    "organization_name": "${formattedData.connection.organization_name}",`);
      console.log(`    "autonomous_system_number": "${formattedData.connection.autonomous_system_number}",`);
      console.log(`    "autonomous_system_organization": "${formattedData.connection.autonomous_system_organization}",`);
      console.log(`    "connection_type": "${formattedData.connection.connection_type}"`);
      console.log(`  },`);
      console.log(`  "flag": {`);
      console.log(`    "emoji": "${formattedData.flag.emoji}",`);
      console.log(`    "png": "${formattedData.flag.png}",`);
      console.log(`    "svg": "${formattedData.flag.svg}"`);
      console.log(`  }`);
      console.log('}');
    } else {
      console.log(chalk.red("Invalid IP address."));
    }
  } catch (error) {
    console.error(chalk.red("Error retrieving IP geolocation: " + error.message));
  }
}

// Get command line arguments
const ipAddress = process.argv[2];
const apiKey = process.argv[3];

if (!ipAddress || !apiKey) {
  console.error(chalk.red("Usage: node ipGeolocation.js <ip_address> <api_key>"));
  process.exit(1);
}

getIpGeolocation(apiKey, ipAddress);