import { ApifyClient } from 'apify-client';

console.log("    Coded By OwlBird");

// Get user input
const inquirer = await (await import("inquirer")).default;
const answer = await inquirer.prompt([{
  'type': 'input',
  'name': 'user',
  'message': "\n    Enter Telegram Channel:"
}]);

// Initialize Apify client with API token
const client = new ApifyClient({
  'token': "apify_api_xPaV5IevgwHvTuR9vYHCfxnQZRZys63L4VS6"
});

// Prepare input for the Telegram scraper
const input = {
  'channels': [answer.user],
  'postsFrom': 10,
  'postsTo': 20,
  'proxy': {
    'useApifyProxy': true,
    'apifyProxyGroups': ['RESIDENTIAL']
  }
};

// Run the Telegram channel scraper
(async () => {
  const run = await client.actor('danielmilevski9/telegram-channel-scraper').call(input);
  
  console.log("Results from dataset");
  
  // Get and display the scraped data
  const { items: channelData } = await client.dataset(run.defaultDatasetId).listItems();
  
  channelData.forEach(post => {
    console.dir(post);
  });
})();