import { ApifyClient } from 'apify-client';

console.log("    Coded By OwlBird");

// Get user input
const inquirer = await (await import("inquirer")).default;
const answer = await inquirer.prompt([{
  'type': "input",
  'name': "user",
  'message': "\n    Enter URL (ex:https://example.com):"
}]);

// Initialize Apify client with API token
const client = new ApifyClient({
  'token': "apify_api_xPaV5IevgwHvTuR9vYHCfxnQZRZys63L4VS6"
});

// Prepare input for the contact info scraper
const input = {
  'startUrls': [{
    'url': answer.user
  }],
  'maxRequestsPerStartUrl': 20,
  'maxDepth': 2,
  'maxRequests': 9999999
};

// Run the contact information scraper
(async () => {
  const run = await client.actor("vdrmota/contact-info-scraper").call(input);
  
  console.log("Results from dataset");
  
  // Get and display the scraped data
  const { items: contactData } = await client.dataset(run.defaultDatasetId).listItems();
  
  contactData.forEach(contact => {
    console.dir(contact);
  });
})();