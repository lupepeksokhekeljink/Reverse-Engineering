import axios from 'axios';
import chalk from 'chalk';

async function validateWithNumLookup(phoneNumber, apiKey) {
  const apiUrl = `https://api.numlookupapi.com/v1/validate/${phoneNumber}?apikey=${apiKey}`;
  
  try {
    const response = await axios.get(apiUrl);
    const data = response.data;
    
    if (data.valid) {
      const formattedData = {
        'number': chalk.cyan(data.number),
        'local_format': chalk.cyan(data.local_format),
        'international_format': chalk.cyan(data.international_format),
        'country_prefix': chalk.green(data.country_prefix),
        'country_code': chalk.green(data.country_code),
        'country_name': chalk.green(data.country_name),
        'location': chalk.green(data.location || 'Unknown'),
        'carrier': chalk.green(data.carrier || "Unknown"),
        'line_type': chalk.green(data.line_type || "Unknown")
      };

      console.log(chalk.blue("Results from OwlTrack API 1:"));
      console.log('{');
      console.log(`  "number": "${formattedData.number}",`);
      console.log(`  "local_format": "${formattedData.local_format}",`);
      console.log(`  "international_format": "${formattedData.international_format}",`);
      console.log(`  "country_prefix": "${formattedData.country_prefix}",`);
      console.log(`  "country_code": "${formattedData.country_code}",`);
      console.log(`  "country_name": "${formattedData.country_name}",`);
      console.log(`  "location": "${formattedData.location}",`);
      console.log(`  "carrier": "${formattedData.carrier}",`);
      console.log(`  "line_type": "${formattedData.line_type}"`);
      console.log('}');
    } else {
      console.log(chalk.red(`Number ${phoneNumber} is not valid according to OwlTrack API.`));
    }
  } catch (error) {
    console.error(chalk.red(`Error fetching details for ${phoneNumber} from OwlTrack API: ${error.message}`));
  }
}

async function validateWithAbstract(apiKey, phoneNumber) {
  const apiUrl = `https://phonevalidation.abstractapi.com/v1/?api_key=${apiKey}&phone=${phoneNumber}`;
  
  try {
    const response = await axios.get(apiUrl);
    const data = response.data;
    
    if (data.valid) {
      const formattedData = {
        'number': chalk.cyan(data.phone),
        'local_format': chalk.cyan(data.local_format),
        'international_format': chalk.cyan(data.international_format),
        'country_prefix': chalk.green(data.country_prefix),
        'country_code': chalk.green(data.country_code),
        'country_name': chalk.green(data.country_name),
        'location': chalk.green(data.location || "Unknown"),
        'carrier': chalk.green(data.carrier || "Unknown"),
        'line_type': chalk.green(data.line_type || "Unknown")
      };

      console.log(chalk.blue("Results from OwlTrack API 2:"));
      console.log('{');
      console.log(`  "number": "${formattedData.number}",`);
      console.log(`  "local_format": "${formattedData.local_format}",`);
      console.log(`  "international_format": "${formattedData.international_format}",`);
      console.log(`  "country_prefix": "${formattedData.country_prefix}",`);
      console.log(`  "country_code": "${formattedData.country_code}",`);
      console.log(`  "country_name": "${formattedData.country_name}",`);
      console.log(`  "location": "${formattedData.location}",`);
      console.log(`  "carrier": "${formattedData.carrier}",`);
      console.log(`  "line_type": "${formattedData.line_type}"`);
      console.log('}');
    } else {
      console.log(chalk.red(`Number ${phoneNumber} is not valid according to OwlTrack API.`));
    }
  } catch (error) {
    console.error(chalk.red(`Error validating phone number with OwlTrack API: ${error.message}`));
  }
}

// Get command line arguments
const phoneNumber = process.argv[2];
const apiKeyNumLookup = process.argv[3];
const apiKeyAbstract = process.argv[4];

if (!phoneNumber || !apiKeyNumLookup || !apiKeyAbstract) {
  console.error(chalk.red("Usage: node script.mjs <phone_number> <api_key_numlookup> <api_key_abstract>"));
  process.exit(1);
}

// Run both validation services
(async () => {
  console.log(chalk.yellow(`\nValidating ${phoneNumber} with OwlTrack API 1...`));
  await validateWithNumLookup(phoneNumber, apiKeyNumLookup);
  
  console.log(chalk.yellow(`\nValidating ${phoneNumber} with OwlTrack API 2...`));
  await validateWithAbstract(apiKeyAbstract, phoneNumber);
})();