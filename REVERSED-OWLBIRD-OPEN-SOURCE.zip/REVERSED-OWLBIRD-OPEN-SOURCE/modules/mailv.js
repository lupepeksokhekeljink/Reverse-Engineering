import axios from 'axios';
import chalk from 'chalk';

async function validateEmail(apiKey, email) {
  const apiUrl = `https://emailvalidation.abstractapi.com/v1/?api_key=${apiKey}&email=${email}`;
  
  try {
    const response = await axios.get(apiUrl);
    const data = response.data;
    
    if (data.is_valid_format.value) {
      const formattedData = {
        'email': chalk.cyan(data.email),
        'is_valid_format': chalk.green(data.is_valid_format.value),
        'is_free_email': chalk.green(data.is_free_email.value),
        'is_disposable_email': chalk.green(data.is_disposable_email.value),
        'is_role_email': chalk.green(data.is_role_email.value),
        'is_catchall_email': chalk.yellow(data.is_catchall_email.value),
        'is_mx_found': chalk.yellow(data.is_mx_found.value),
        'is_smtp_valid': chalk.yellow(data.is_smtp_valid.value)
      };

      console.log('{');
      console.log(`  "email": "${formattedData.email}",`);
      console.log(`  "is_valid_format": "${formattedData.is_valid_format}",`);
      console.log(`  "is_free_email": "${formattedData.is_free_email}",`);
      console.log(`  "is_disposable_email": "${formattedData.is_disposable_email}",`);
      console.log(`  "is_role_email": "${formattedData.is_role_email}",`);
      console.log(`  "is_catchall_email": "${formattedData.is_catchall_email}",`);
      console.log(`  "is_mx_found": "${formattedData.is_mx_found}",`);
      console.log(`  "is_smtp_valid": "${formattedData.is_smtp_valid}"`);
      console.log('}');
    } else {
      console.log(chalk.red("Invalid email address."));
    }
  } catch (error) {
    console.error(chalk.red("Error validating email: " + error.message));
  }
}

// Get command line arguments
const email = process.argv[2];
const apiKey = process.argv[3];

if (!email || !apiKey) {
  console.error(chalk.red("Usage: node emailValidator.js <email> <api_key>"));
  process.exit(1);
}

validateEmail(apiKey, email);