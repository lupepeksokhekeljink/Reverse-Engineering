import HeaderHelp from 'headerhelp';
import chalk from 'chalk';

const header = new HeaderHelp({
  'bannerTitle': "CCTV-Hijack",
  'bannerStyle': "ANSI Shadow",
  'bannerColor': ["#ffd700", "#f8f8ff"],
  'littleTitle': true
});

header.setArgs({
  'separator': chalk.green('—'),
  'name': " CCTV Hijacker ",
  'info': ['Searching']
});

header.print();
console.log(chalk.red("Ctrl + C To Stop The Program"));