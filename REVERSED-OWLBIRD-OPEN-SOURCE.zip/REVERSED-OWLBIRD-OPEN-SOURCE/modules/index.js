import 'dotenv/config';
import wabotAI from 'wabot-ai';

const {
  HyWaBot,
  HytechMessages,
  HytechHandle,
  HytechHandleGemini
} = wabotAI;

// Log environment variables for debugging
console.log("Environment Variables:");
console.log("PHONE:", process.env.PHONE);
console.log("OPENAI_API_KEY:", process.env.OPENAI_API_KEY);
console.log('PREFIX_OPENAI:', process.env.PREFIX_OPENAI);
console.log("PREFIX_GEMINI:", process.env.PREFIX_GEMINI);

// Validate required environment variables
if (!process.env.OPENAI_API_KEY || !process.env.PREFIX_OPENAI || !process.env.PREFIX_GEMINI) {
  throw new Error("Missing required environment variables. Check your .env file.");
}

// Bot configuration
const botConfig = {
  'phoneNumber': process.env.PHONE,
  'sessionId': "session",
  'useStore': true
};

const bot = new HyWaBot(botConfig);

// Start the bot
bot.start().then(whatsappClient => {
  console.log("Bot started successfully.");
  
  // Handle incoming messages
  whatsappClient.ev.on("messages.upsert", async (messageData) => {
    try {
      const message = messageData.messages[0];
      
      // Skip if no message content
      if (!message.message) {
        return;
      }

      // Process the message
      const processedMessage = await HytechMessages(message);
      console.log("Processed message:", processedMessage);

      let messageText;
      
      // Extract message text based on chat type
      if (processedMessage.chatsFrom === "private") {
        messageText = processedMessage.message;
      } else if (processedMessage.chatsFrom === "group") {
        messageText = processedMessage.participant ? 
          processedMessage.participant.message : 
          processedMessage.message;
      }

      // Handle OpenAI commands
      if (messageText.startsWith(process.env.PREFIX_OPENAI)) {
        const query = messageText.replace(process.env.PREFIX_OPENAI, '').trim();
        const response = await HytechHandle(query);
        
        whatsappClient.sendMessage(processedMessage.remoteJid, {
          'text': response
        });
      }

      // Handle Gemini commands
      if (messageText.startsWith(process.env.PREFIX_GEMINI)) {
        const query = messageText.replace(process.env.PREFIX_GEMINI, '').trim();
        const response = await HytechHandleGemini(query);
        
        whatsappClient.sendMessage(processedMessage.remoteJid, {
          'text': response
        });
      }

      // Handle source command
      if (messageText.startsWith(".source")) {
        whatsappClient.sendMessage(processedMessage.remoteJid, {
          'text': "*WhatsApp Bot OpenAI*\n\nWhatsApp Chatbot for AI-based conversations using OpenAI technology.\n\n- Github: https://github.com/HyTech-Group/wabot-ai\n- Npm: https://www.npmjs.com/package/wabot-ai\n- Official Website: https://hy-tech.my.id/"
        });
      }
      
    } catch (error) {
      console.error("Error processing message:", error);
    }
  });
}).catch(error => {
  console.error("Error starting bot:", error);
});

// Error handling
process.on("unhandledRejection", (reason) => {
  console.error("Unhandled Rejection:", reason);
});

process.on("uncaughtException", (error) => {
  console.error("Uncaught Exception:", error);
});