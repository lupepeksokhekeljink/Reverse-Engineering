#!/bin/bash

echo -e "\033[1;91m An Open Source Intelligence Framework Created by: ANONYMINHACK5 Re-Coded by: OwlBird Team: Intelligence Cyber Community Version: \033[1;92m2.3 \033[0m"
echo

printf "\e[1;34m\tSelect your terminal to install OwlTrack \e[0m\n"
printf "\e[1;91m\t[!] PLEASE MAKE SURE YOU CHOOSE CORRECTLY [!] \e[0m\n\n"
printf "\e[1;34m\t\t[\e[0m\e[1;77m01\e[0m\e[1;34m]\e[0m\e[1;93mTermux\e[0m\e[1;91m [STABLE]\e[0m\n"
printf "\e[1;34m\t\t[\e[0m\e[1;77m02\e[0m\e[1;34m]\e[0m\e[1;93mLinux\e[0m\n"

read -p $'\n\e[1;92m[\e[0m\e[1;77m*\e[0m\e[1;92m] Choose your terminal: \e[0m\en' terminal

if [[ $terminal == "1" || $terminal == "01" ]]; then
    printf "\e[1;94mYou have chosen Termux as your current terminal. Packages for Termux will start to install... \e[0m\n"
    sleep 3
    
    echo -e "\033[1;91m[*] \033[1;97m Allow file/move permission \033[0m"
    termux-setup-storage
    
    echo -e "\033[1;91m[*]\033[1;97m Installing required packages \033[0m"
    pkg update -y
    pkg upgrade -y
    pkg install python3 -y
    pkg install python-numpy -y
    pip install requests phonenumbers bs4 twilio instaloader argparse colorama opencage googlesearch-python faker lolcat folium
    
    echo -e "\033[1;91m[*]\033[1;97m OwlTrack installed successfully. Now it's ready for use. Re-open your Termux to use OwlTrack \e[0m"
    printf "\e[1;91m[*] After reopening Termux, type '\e[1;91mpython owltrack\e[1;97m' to launch OwlTrack \e[0m"
    exit

elif [[ $terminal == "2" || $terminal == "02" ]]; then
    printf "\e[1;94mYou have chosen Linux as your current terminal. Packages for Linux will start to install... \e[0m\n"
    sleep 2
    
    sudo apt-get update -y
    sudo apt-get upgrade -y
    pip install lolcat requests phonenumbers folium colorama twilio instaloader bs4 argparse opencage googlesearch-python faker
    sudo apt-get install python3-numpy -y
    
    echo -e "\033[1;91m[*]\033[1;97m OwlTrack installed successfully. Now it's ready for use. Re-open your Linux terminal to use OwlTrack \e[0m"
    printf "\e[1;91m[*] After reopening your terminal, type '\e[1;91msudo owltrack\e[1;97m' to launch OwlTrack \e[0m"
    exit

else
    printf "\e[0m\e[1;91m [\e[1;97m~\e[1;91m]\e[1;93m Sorry, that's not in the options! Open your eyes... \e[0m\e[1;91m[\e[0m\e[1;97m~\e[0m\e[1;91m]\e[0m\n"
    sleep 1
    python owltrack.py
fi