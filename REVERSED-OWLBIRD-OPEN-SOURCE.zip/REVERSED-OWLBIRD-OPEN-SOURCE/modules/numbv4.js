import fetch from 'node-fetch';
import chalk from 'chalk';

const phoneNumber = process.argv[2];
const countryCode = process.argv[3];
const localityLanguage = process.argv[4];

// API URL with hardcoded API key
const url = `https://api-bdc.net/data/phone-number-validate?number=${phoneNumber}&countryCode=${countryCode}&localityLanguage=${localityLanguage}&key=bdc_5f4b9b5265c844dc8a1edd2bd3e128de`;

const validatePhoneNumber = async () => {
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    console.log(chalk.blue("Phone Number Validation Result:"));
    console.log(chalk.white("\"isValid\": ") + (data.isValid ? chalk.yellow(data.isValid) : chalk.red(data.isValid)));
    console.log(chalk.white("\"e164Format\": ") + chalk.green(data.e164Format));
    console.log(chalk.white("\"internationalFormat\": ") + chalk.green(data.internationalFormat));
    console.log(chalk.white("\"nationalFormat\": ") + chalk.green(data.nationalFormat));
    console.log(chalk.white("\"location\": ") + chalk.green(data.location));
    console.log(chalk.white("\"lineType\": ") + chalk.green(data.lineType));
    
    console.log(chalk.white("\"country\": {"));
    console.log("  " + chalk.white("\"isoAlpha2\": ") + chalk.yellow(data.country.isoAlpha2));
    console.log("  " + chalk.white("\"isoAlpha3\": ") + chalk.yellow(data.country.isoAlpha3));
    console.log("  " + chalk.white("\"m49Code\": ") + chalk.yellow(data.country.m49Code));
    console.log("  " + chalk.white("\"name\": ") + chalk.green(data.country.name));
    console.log("  " + chalk.white("\"isoName\": ") + chalk.green(data.country.isoName));
    console.log("  " + chalk.white("\"isoNameFull\": ") + chalk.green(data.country.isoNameFull));
    
    if (data.country.isoAdminLanguages) {
      console.log(chalk.white("  \"isoAdminLanguages\": ["));
      data.country.isoAdminLanguages.forEach((language, index) => {
        console.log("    " + chalk.white(index + 1) + ". " + chalk.green(language.isoName) + " (" + chalk.green(language.nativeName) + ')');
      });
      console.log(chalk.white("  ]"));
    }
    
    console.log("  " + chalk.white("\"currency\": {"));
    console.log("    " + chalk.white("\"code\": ") + chalk.yellow(data.country.currency.code));
    console.log("    " + chalk.white("\"name\": ") + chalk.green(data.country.currency.name));
    console.log("    " + chalk.white("\"minorUnits\": ") + chalk.yellow(data.country.currency.minorUnits));
    console.log("  }");
    
    console.log("  " + chalk.white("\"wbRegion\": {"));
    console.log("    " + chalk.white("\"value\": ") + chalk.green(data.country.wbRegion.value));
    console.log("  }");
    
    console.log("  " + chalk.white("\"wbIncomeLevel\": {"));
    console.log("    " + chalk.white("\"value\": ") + chalk.green(data.country.wbIncomeLevel.value));
    console.log("  }");
    
    console.log("  " + chalk.white("\"callingCode\": ") + chalk.yellow(data.country.callingCode));
    console.log("  " + chalk.white("\"countryFlagEmoji\": ") + chalk.green(data.country.countryFlagEmoji));
    console.log("  " + chalk.white("\"wikidataId\": ") + chalk.yellow(data.country.wikidataId));
    console.log("  " + chalk.white("\"geonameId\": ") + chalk.yellow(data.country.geonameId));
    console.log("  " + chalk.white("\"isIndependent\": ") + (data.country.isIndependent ? chalk.yellow(data.country.isIndependent) : chalk.red(data.country.isIndependent)));
    console.log('}');
    
  } catch (error) {
    console.error(chalk.red('Error:'), error);
  }
};

if (!phoneNumber || !countryCode || !localityLanguage) {
  console.log(chalk.red("Usage: node namascript.js <phone_number> <countryCode> <localityLanguage>"));
} else {
  validatePhoneNumber();
}