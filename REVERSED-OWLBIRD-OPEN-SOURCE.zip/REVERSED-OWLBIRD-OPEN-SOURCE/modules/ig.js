import { ApifyClient } from 'apify-client';

console.log("    Coded By Denis Putra X OwlBird");

// Get user input
const inquirer = await (await import("inquirer")).default;
const answer = await inquirer.prompt([{
  'type': "input",
  'name': "user",
  'message': "\n    Enter Instagram User:"
}]);

// Initialize Apify client with API token
const client = new ApifyClient({
  'token': "apify_api_xPaV5IevgwHvTuR9vYHCfxnQZRZys63L4VS6"
});

// Prepare input for the scraper
const input = {
  'usernames': [answer.user]
};

// Run the Instagram scraper
(async () => {
  const run = await client.actor("apify/instagram-profile-scraper").call(input);
  
  console.log("Results from dataset");
  
  // Get and display the scraped data
  const { items: profileData } = await client.dataset(run.defaultDatasetId).listItems();
  
  profileData.forEach(profile => {
    console.dir(profile);
  });
})();