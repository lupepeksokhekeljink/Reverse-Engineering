from time import sleep
import re
import json
import requests
import os

def email_info():
    """Email information validator"""
    mailid = input('\x1b[91m[\x1b[94mUser@localhost\x1b[91m]\x1b[1;97m Enter email address \x1b[0m[\x1b[101mxxx@gmail.com\x1b[0m] \x1b[0m➤: ')
    
    # Validasi format email
    if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', mailid):
        print('Please input a valid Email Address!')
        return
    
    # API request untuk validasi email
    url = f"https://api.emailable.com/v1/verify?email={mailid}&api_key=demo"
    eml = requests.get(url).json()
    
    if str(eml['success']) == 'False':
        print(eml['message'])
        return
    
    print()
    sleep(1)
    print()
    
    print('\x1b[1;91m[\x1b[92m~\x1b[91m]\x1b[1;97m E-mail Details are given down below')
    print()
    
    # Display email information
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Target E-mail       : ' + str(mailid))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Status Code         : ' + str(eml['status_code']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Valid               : ' + str(eml['valid']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Catch All           : ' + str(eml['catch_all']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Common              : ' + str(eml['common']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Deliverability      : ' + str(eml['deliverability']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Disposable          : ' + str(eml['disposable']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m DNS Valid           : ' + str(eml['dns_valid']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Fraud Score         : ' + str(eml['fraud_score']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Frequent Complainer : ' + str(eml['frequent_complainer']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Generic             : ' + str(eml['generic']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Honeypot            : ' + str(eml['honeypot']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Leaked              : ' + str(eml['leaked']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Message             : ' + str(eml['message']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Over All Score      : ' + str(eml['overall_score']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Recent Abuse        : ' + str(eml['recent_abuse']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Request ID          : ' + str(eml['request_id']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Sanitized E-mail    : ' + str(eml['sanitized_email']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m SMTP Score          : ' + str(eml['smtp_score']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Spam Trap Score     : ' + str(eml['spam_trap_score']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Success             : ' + str(eml['success']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Suggested Domain    : ' + str(eml['suggested_domain']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Suspect             : ' + str(eml['suspect']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Timed Out           : ' + str(eml['timed_out']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m First Name          : ' + str(eml['first_name']))
    sleep(0.1)
    
    print()
    print('\x1b[1;91m[\x1b[92m~\x1b[91m]\x1b[1;94m Domain Age')
    print()
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Human      : ' + str(eml['domain_age']['human']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m ISO        : ' + str(eml['domain_age']['iso']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Time Stamp : ' + str(eml['domain_age']['timestamp']))
    sleep(0.1)
    
    print()
    print('\x1b[1;91m[\x1b[92m~\x1b[91m]\x1b[1;94m First Seen')
    print()
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Human      : ' + str(eml['first_seen']['human']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m ISO        : ' + str(eml['first_seen']['iso']))
    sleep(0.1)
    
    print('\x1b[1;91m[\x1b[92m>\x1b[91m]\x1b[1;97m Time Stamp : ' + str(eml['first_seen']['timestamp']))
    sleep(0.1)
    
    print()
    
    # Exit atau lanjut ke input baru
    exit()
    email_info()

# Jalankan fungsi utama
email_info()