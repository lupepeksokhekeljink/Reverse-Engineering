import os
import sys
import subprocess
import getpass
import webbrowser
import platform
from time import sleep
import requests

def safe_remove(path):
    """Hapus file dengan error handling"""
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception as e:
        print(f'\x1b[93m[\x1b[91m!\x1b[93m] \x1b[91mError removing {path}: {e}\x1b[0m')

def masuk():
    """Tampilan banner masuk"""
    from time import sleep
    import os
    
    os.system('cls' if os.name == 'nt' else 'clear')
    sleep(0.1)
    print('\x1b[91m╻ ╻╻ ╻╻┏━┓   \x1b[1;97m╺┳╸┏━┓┏━┓┏━╸╻┏ ┏━╸┏━┓   \x1b[1;96m┏━┓┏━┓╻┏┓╻╺┳╸   ╺┳╸┏━┓┏━┓╻  ┏━┓')
    sleep(0.1)
    print('\x1b[91m┃┏┛┃┏┛┃┣━┛   \x1b[1;97m ┃ ┣┳┛┣━┫┃  ┣┻┓┣╸ ┣┳┛   \x1b[1;96m┃ ┃┗━┓┃┃┗┫ ┃     ┃ ┃ ┃┃ ┃┃  ┗━┓')
    sleep(0.1)
    print('\x1b[91m┗┛ ┗┛ ╹╹     \x1b[1;97m ╹ ╹┗╸╹ ╹┗━╸╹ ╹┗━╸╹┗╸   \x1b[1;96m┗━┛┗━┛╹╹ ╹ ╹     ╹ ┗━┛┗━┛┗━╸┗━┛')
    sleep(0.1)
    print('\x1b[1;0m--------------------------------------------------------------------')
    sleep(0.1)
    print('              \x1b[101mVersion \x1b[1;96m2.6\x1b[101m - 2025 coded by Mr,OwlBird05\x1b[0m')
    sleep(0.1)
    print()
    sleep(0.2)

def terms():
    """Tampilan terms"""
    from time import sleep
    import os
    
    os.system('cls' if os.name == 'nt' else 'clear')
    print()
    sleep(1)
    print(' ╻┏ ┏━╸╺┳╸┏━╸┏┓╻╺┳╸╻ ╻┏━┓┏┓╻   ╻  ┏━┓╻ ╻┏━┓┏┓╻┏━┓┏┓╻')
    sleep(0.1)
    print(' ┣┻┓┣╸  ┃ ┣╸ ┃┗┫ ┃ ┃ ┃┣━┫┃┗┫   ┃  ┣━┫┗┳┛┣━┫┃┗┫┣━┫┃┗┫')
    sleep(0.1)
    print(' ╹ ╹┗━╸ ╹ ┗━╸╹ ╹ ╹ ┗━┛╹ ╹╹ ╹   ┗━╸╹ ╹ ╹ ╹ ╹╹ ╹╹ ╹╹ ╹')
    sleep(0.1)
    print('\x1b[1;0m-----------------------------------------------------')
    sleep(0.1)
    print('                \x1b[0m[\x1b[101mCreated By OwlBird05\x1b[0m]\x1b[0m')
    sleep(0.1)
    print()

def modul():
    """Menu modul utama"""
    from time import sleep
    import os
    import sys
    
    sleep(1)
    os.system('cls' if os.name == 'nt' else 'clear')
    sleep(1)
    print()
    sleep(0.1)
    print('╻┏┓╻┏━┓╺┳╸┏━┓╻  ╻  ┏━┓╺┳╸╻┏━┓┏┓╻   \x1b[1;96m┏┳┓┏━┓╺┳┓╻ ╻╻  ┏━╸┏━┓\x1b[0m')
    sleep(0.1)
    print('┃┃┗┫┗━┓ ┃ ┣━┫┃  ┃  ┣━┫ ┃ ┃┃ ┃┃┗┫   \x1b[1;96m┃┃┃┃ ┃ ┃┃┃ ┃┃  ┣╸ ┗━┓\x1b[0m')
    sleep(0.1)
    print('╹╹ ╹┗━┛ ╹ ╹ ╹┗━╸┗━╸╹ ╹ ╹ ╹┗━┛╹ ╹   \x1b[1;96m╹ ╹┗━┛╺┻┛┗━┛┗━╸┗━╸┗━┛\x1b[0m')
    sleep(0.1)
    print('\x1b[1;0m---------------------------------------------------------')
    sleep(0.1)
    print('           \x1b[101mVersion \x1b[1;96m2.6\x1b[101m - 2025 coded by Mr,OwlBird05\x1b[0m')
    sleep(0.1)
    print()
    print('\x1b[101m\x1b[91m[\x1b[0m>\x1b[91m]\x1b[0;37m Jika Tools Error Harap Install Bahan Bahan Terlebih Dahulu')
    print('\x1b[101m\x1b[91m[\x1b[0m>\x1b[91m]\x1b[0;37m If The Tools Has An Error Please Install Module First')
    print('\n        \x1b[91m[\x1b[92m1\x1b[91m]\x1b[0m Install Python Module\n        \x1b[91m[\x1b[92m2\x1b[91m]\x1b[0m Install NodeJS Module \x1b[91m[\x1b[1;96mNew\x1b[91m]\n        \x1b[91m[\x1b[92m3\x1b[91m]\x1b[0m Next To OwlTrack\n        \x1b[91m[\x1b[92m4\x1b[91m]\x1b[0m Exit')
    print('')
    
    try:
        module = int(input('\x1b[91m[\x1b[94mUser@localhost\x1b[91m]\x1b[0;37m Chose an Option: ').strip())
        
        if module == 1:
            sleep(0.5)
            os.system('bash modules/setup.sh')
            modul()
            
        elif module == 2:
            sleep(0.5)
            os.system('pkg update && pkg upgrade -y && pkg install nodejs && pkg install nodejs-lts && node -v && cd modules && npm install && npm install axios chalk@4 readline url apify-client cheerio node-fetch deobfuscator pino @hapi/boom file-type lodash moment-timezone awesome-phonenumber node-cache @whiskeysockets/baileys user-agents fake-useragent net http2 tls cluster crypto fs axios cheerio gradient-string child_process dgram headerhelp && cd ../Developer && npm install terminal-kit figlet inquirer awesome-phonenumber truecallerjs && cd ../modules/bugv && npm i')
            print('\x1b[91m[\x1b[92m+\x1b[91m]\x1b[0m Done.')
            sleep(1)
            modul()
            
        elif module == 3:
            os.system('python modules/MODULE')
            
        elif module == 4:
            sys.exit(1)
            
        else:
            print('\x1b[91m[\x1b[91m!\x1b[91m]\x1b[0m Invalid option.')
            sleep(1)
            modul()
            
    except ValueError:
        print('\x1b[91m[\x1b[91m!\x1b[91m]\x1b[0m Invalid input, please enter a number.')
        sleep(1)
        modul()
    except KeyboardInterrupt:
        type_effect('\n\x1b[93m[\x1b[91m!\x1b[93m] \x1b[1;97mProgram terminated by user.')
        sys.exit()

def type_effect(text, delay=0.05):
    """Efek ketik"""
    import time
    
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write('\n')

def type_effect2(text, delay=0.05):
    """Efek ketik dengan error handling"""
    import time
    
    try:
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)
        sys.stdout.write('\n')
    except KeyboardInterrupt:
        type_effect('\n\x1b[93m[\x1b[91m!\x1b[93m] \x1b[1;97mProgram terminated by user. Removing user.txt')
        safe_remove('user.txt')
        sys.exit()

def print_terms_of_service():
    """Tampilkan terms of service"""
    terms()
    type_effect2('\x1b[1;97m=== Ketentuan Layanan (Terms of Service) ===\n\x1b[0m', 0.05)
    
    type_effect2('1. Penerimaan Ketentuan')
    type_effect2('   Dengan mengakses atau menggunakan OwlTrack, Anda menyatakan bahwa Anda telah membaca, memahami, dan menyetujui seluruh ketentuan ini.')
    type_effect2('   Jika Anda tidak menyetujui, Anda dilarang keras untuk menggunakan tools ini dan diwajibkan segera menghentikan segala bentuk penggunaannya.\n')
    
    type_effect2('2. Deskripsi Tools')
    type_effect2('   OwlTrack adalah perangkat lunak berpemilik yang dikembangkan oleh OwlBird/Abid .Z, ditujukan untuk keperluan riset keamanan siber, pelacakan aktivitas, dan otomatisasi data.')
    type_effect2('   Tools ini bersifat eksklusif, terenkripsi, dan tidak open-source. Setiap upaya pembongkaran kode tanpa izin akan diproses secara hukum.\n')
    
    type_effect2('3. Penggunaan yang Diizinkan')
    type_effect2('   - Hanya pengguna resmi dan berlisensi yang diperbolehkan menggunakan tools ini.')
    type_effect2('   - Dilarang keras menggunakan tools ini untuk kegiatan ilegal, termasuk namun tidak terbatas pada penyadapan, pemerasan, penguntitan, atau aktivitas yang melanggar hukum lokal maupun internasional.')
    type_effect2('   - Pelanggaran akan dicatat dan dapat dilaporkan kepada otoritas terkait.\n')
    
    type_effect2('4. Hak dan Lisensi')
    type_effect2('   - Lisensi bersifat non-eksklusif, tidak dapat dipindahtangankan, dan hanya berlaku untuk pengguna premium terdaftar.')
    type_effect2('   - Dilarang menyebarluaskan, menjual kembali, atau mengalihkan hak akses tanpa persetujuan tertulis dari pengembang.')
    type_effect2('   - Upaya mendekompilasi, memodifikasi, atau membalikkan rekayasa software ini tanpa izin akan dikenakan sanksi hukum sesuai undang-undang hak cipta dan keamanan informasi yang berlaku.\n')
    
    type_effect2('5. Batasan Tanggung Jawab')
    type_effect2("   - Tools ini disediakan 'SEBAGAIMANA ADANYA' tanpa jaminan dalam bentuk apa pun, eksplisit maupun implisit.")
    type_effect2('   - Pengembang tidak bertanggung jawab atas segala konsekuensi, kerusakan, atau kehilangan yang timbul akibat penggunaan, penyalahgunaan, atau ketergantungan terhadap tools ini.\n')
    
    type_effect2('6. Dukungan dan Pembaruan')
    type_effect2('   - Dukungan teknis hanya tersedia untuk pengguna berlisensi aktif.')
    type_effect2('   - Pembaruan dapat diberikan secara berkala sesuai dengan kebijakan internal dan tidak menjamin fitur atau kompatibilitas masa depan.\n')
    
    type_effect2('7. Perubahan Ketentuan')
    type_effect2('   Ketentuan ini dapat diperbarui sewaktu-waktu tanpa pemberitahuan terlebih dahulu.')
    type_effect2('   Dengan terus menggunakan tools ini setelah perubahan, Anda menyetujui ketentuan terbaru secara otomatis.\n')
    
    type_effect2('8. Penegakan dan Pelaporan')
    type_effect2('   - Setiap pelanggaran terhadap ketentuan ini dapat mengakibatkan pencabutan lisensi, blacklist permanen, dan/atau tindakan hukum.')
    type_effect2('   - Penggunaan ilegal akan dilaporkan ke pihak berwenang jika diperlukan.\n')
    
    type_effect2('9. Kontak Resmi')
    type_effect2('   Untuk laporan pelanggaran, dukungan teknis, atau pertanyaan lainnya, silakan hubungi: investigatorcyberteam@gmail.com.\n')
    
    type_effect2('             \x1b[1;97mSetuju/Saya tidak setuju \x1b[1;93m(Y/N)\x1b[0m: ', 0.05)
    
    try:
        pil = input().strip().lower()
        
        if pil == 'y':
            sleep(1)
            modul()
        elif pil == 'n':
            type_effect('\n\x1b[93m[\x1b[91m!\x1b[93m] \x1b[1;97mRemoving Accsess...')
            safe_remove('user.txt')
            safe_remove('modules/MODULE')
            type_effect('\n\x1b[93m[\x1b[91m!\x1b[93m] \x1b[1;97mAccess removed. \x1b[91mExiting...\x1b[0m')
            sys.exit(1)
            
    except KeyboardInterrupt:
        type_effect('\n\x1b[93m[\x1b[91m!\x1b[93m] \x1b[1;97mProgram terminated by user. Removing user.txt')
        safe_remove('user.txt')
        sys.exit()

def open_link(url):
    """Buka link di browser"""
    system_platform = platform.system().lower()
    
    try:
        if 'android' in platform.uname().release.lower() or 'termux' in os.getenv('HOME', '').lower():
            os.system(f'am start -a android.intent.action.VIEW -d "{url}"')
        else:
            webbrowser.open(url)
    except:
        if system_platform == 'linux':
            os.system(f'xdg-open {url}')
        elif system_platform == 'windows':
            os.system(f'start {url}')
        elif system_platform == 'darwin':
            os.system(f'open {url}')
        else:
            print(f'\x1b[91m[\x1b[92m>\x1b[91m]\x1b[0;37m Please open this link manually: \x1b[92m{url}')

def login():
    """Sistem login"""
    masuk()
    
    if os.path.exists('user.txt') and os.path.getsize('user.txt') > 0:
        with open('user.txt', 'r') as file:
            username = file.readline().strip()
        modul()
    else:
        print('\n\x1b[91m[\x1b[92m>\x1b[91m]\x1b[0;37m Join my group for requirements then request a license')
        print('\x1b[91m[\x1b[92m>\x1b[91m]\x1b[0;37m Or You Can DM My Instagram @iccfficial')
        open_link('https://chat.whatsapp.com/KQZ6iC9cOeT4Rlm5PuEeVq?mode=ems_copy_t')
        
        allowed_user = 'owlbird05'
        print()
        
        try:
            username = input('     🦉 \x1b[1;37mUsername ===>\x1b[1;96m ').strip()
            sleep(0.2)
            
            if username != allowed_user:
                print('\n     🦉 \x1b[1;91mUsername Wrong')
                sleep(2)
                login()
            else:
                with open('user.txt', 'w') as file:
                    file.write(username)
                
                print('\n     🦉 \x1b[0mWelcome To \x1b[1;96mInstallation \x1b[94mModules')
                sleep(1)
                print('\n\x1b[91m[\x1b[92m>\x1b[91m]\x1b[0m Pass saved in: ./user.txt')
                sleep(2)
                print_terms_of_service()
                
        except KeyboardInterrupt:
            type_effect('\n\x1b[93m[\x1b[91m!\x1b[93m] \x1b[1;97mProgram terminated by user.')
            sys.exit()

# Main execution
try:
    login()
except ModuleNotFoundError:
    print('\x1b[91m[\x1b[92m!\x1b[91m]\x1b[0m Module not found, please install the required modules.')
    print('\x1b[91m[\x1b[92m+\x1b[91m]\x1b[0m Installing required modules...')
    sleep(1)
    os.system('pip install requests')
    print('\x1b[91m[\x1b[92m+\x1b[91m]\x1b[0m Modules installed successfully.')
    sleep(1)
    sys.exit()