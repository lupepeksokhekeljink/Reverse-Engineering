const term = require('terminal-kit').terminal;
const figlet = require("figlet");

const lookupNumber = () => {
  return new Promise(async (resolve) => {
    try {
      console.clear();
      
      // Display banner
      term.cyan(figlet.textSync("Lookup", {
        'font': "Speed",
        'horizontalLayout': "default",
        'verticalLayout': "default",
        'width': 80,
        'whitespaceBreak': true
      }));

      // Get user input
      const inquirer = await (await import("inquirer")).default;
      const userInput = await inquirer.prompt([{
        'type': "input",
        'name': "number",
        'message': "\nEnter Number (+62xxx):"
      }]);

      let phoneNumber = userInput.number;
      
      // Add + prefix if missing
      if (!phoneNumber.startsWith('+')) {
        phoneNumber = '+' + userInput.number;
      }

      // Validate phone number
      const phoneUtil = await (await require("awesome-phonenumber")(phoneNumber)).getNumber();
      
      // Prepare Truecaller search parameters
      const searchData = {
        'number': phoneUtil.number.international,
        'countryCode': phoneUtil.regionCode,
        'installationId': 'a1i0E--n8eef1VQVkatn-qsEvXZwinJqkShVgv9Jym-OnmZAorrpa1qIO7HkC6ON'
      };

      // Perform Truecaller lookup
      const truecaller = await (await import("truecallerjs")).default;
      const result = await truecaller.search(searchData);
      
      // Display results
      console.log("\x1b[32m", "Success Lookup: " + phoneNumber + "\n\n" + result.yaml(), "\x1b[0m");

      // Ask user if they want to retry
      setTimeout(async () => {
        const prompt = await (await import('inquirer')).default;
        prompt.prompt([{
          'type': "list",
          'name': 'menuOption',
          'message': "Success Lookup, Want to Retry? (yes/no): ",
          'choices': ["yes", "no"]
        }]).then(choice => {
          switch (choice.menuOption) {
            case 'yes':
              console.clear();
              lookupNumber();
              break;
            case 'no':
              console.clear();
              process.exit();
              break;
            default:
              console.log("Invalid choice");
              break;
          }
        });
      }, 1000);

    } catch (error) {
      console.log("An error occurred:", error);
    }
  });
};

// Start the application
lookupNumber();