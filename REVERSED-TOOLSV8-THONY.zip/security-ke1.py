import subprocess
import sys
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

# Color codes
r = '\x1b[1;31m'
g = '\x1b[1;32m'
c = '\x1b[1;36m'

# Constants
REPO_NAME = '.Jembut__Lu__Memek'
VERSION = '32'
REPO_URL = 'https://github.com/Blackheat023/.Jembut__Lu__Memek'
SCRIPT_NAME = 'Kroco.sh'
AUTHOR = 'Yatim_Lo_Bego404'

def run_command(cmd, check=True):
    """
    Menjalankan command shell
    """
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    if check:
        if result.returncode != 0:
            clear_screen()
            print()
            print(f'{r}[ {g}EROR {r}] {c}Toolsv8 sedang dalam perbaikan.')
            print()
            sys.exit(1)
    
    return result

def clear_screen():
    """
    Membersihkan layar terminal
    """
    subprocess.run('clear', shell=True)

def main():
    """
    Fungsi utama
    """
    clear_screen()
    
    # Banner
    print(f'{r}╔════════════════════════════════════════╗')
    print(f'{r}║             {g}TOOLSV8 {r}                   ║')
    print(f'{r}║    {c}Created by: {AUTHOR}{r}           ║')
    print(f'{r}║    {c}Version: {VERSION}{r}                          ║')
    print(f'{r}╚════════════════════════════════════════╝')
    print()
    
    # Check internet connection
    print(f'{c}[{g}INFO{c}] Checking internet connection...')
    internet_check = run_command('ping -c 1 google.com', check=False)
    
    if internet_check.returncode != 0:
        print(f'{r}[{g}ERROR{r}] No internet connection!')
        sys.exit(1)
    
    print(f'{g}[{c}SUCCESS{g}] Internet connected!')
    print()
    
    # Main menu
    while True:
        print(f'{c}=== MAIN MENU ===')
        print(f'{g}1. Install Tools')
        print(f'{g}2. Update Tools') 
        print(f'{g}3. About')
        print(f'{g}0. Exit')
        print()
        
        choice = input(f'{c}Select option: {g}')
        
        if choice == '1':
            install_tools()
        elif choice == '2':
            update_tools()
        elif choice == '3':
            about()
        elif choice == '0':
            print(f'{c}Thanks for using Toolsv8!')
            sys.exit(0)
        else:
            print(f'{r}Invalid option!')

def install_tools():
    """
    Install tools dari repository
    """
    clear_screen()
    print(f'{c}[{g}INFO{c}] Installing tools...')
    
    try:
        # Clone repository
        run_command(f'git clone {REPO_URL}')
        
        # Run installation script
        run_command(f'cd {REPO_NAME} && bash {SCRIPT_NAME}')
        
        print(f'{g}[{c}SUCCESS{g}] Tools installed successfully!')
        
    except Exception as e:
        print(f'{r}[{g}ERROR{r}] Installation failed: {e}')

def update_tools():
    """
    Update tools ke versi terbaru
    """
    clear_screen()
    print(f'{c}[{g}INFO{c}] Updating tools...')
    
    try:
        # Check if repository exists
        result = run_command(f'[ -d "{REPO_NAME}" ] && echo "exists"', check=False)
        
        if 'exists' not in result.stdout:
            print(f'{r}[{g}ERROR{r}] Repository not found. Please install first.')
            return
        
        # Update repository
        run_command(f'cd {REPO_NAME} && git pull')
        
        print(f'{g}[{c}SUCCESS{g}] Tools updated successfully!')
        
    except Exception as e:
        print(f'{r}[{g}ERROR{r}] Update failed: {e}')

def about():
    """
    Menampilkan informasi tentang Toolsv8
    """
    clear_screen()
    print(f'{c}=== ABOUT TOOLSV8 ===')
    print(f'{g}Author: {c}{AUTHOR}')
    print(f'{g}Version: {c}{VERSION}')
    print(f'{g}Repository: {c}{REPO_URL}')
    print(f'{g}Script: {c}{SCRIPT_NAME}')
    print()
    print(f'{c}Description:')
    print(f'{g}Toolsv8 adalah kumpulan tools hacking dan penetration testing')
    print(f'{g}yang dikembangkan untuk tujuan edukasi dan keamanan.')
    print()
    input(f'{c}Press Enter to continue...')

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f'\n{c}Program interrupted by user')
        sys.exit(0)
    except Exception as e:
        print(f'{r}Unexpected error: {e}')
        sys.exit(1)