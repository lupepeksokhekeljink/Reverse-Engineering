b='\033[34;1m'
g='\033[32;1m'
p='\033[35;1m'
c='\033[36;1m'
r='\033[31;1m'
y='\033[33;1m'
bold_bg='\033[41;1m'
bold_gren='\033[1;32m'
n='\033[0m'
red='\033[31;1m'
green='\033[32;1m'
yellow='\033[33;1m'
cyan='\033[36;1m'
if ! test -z "$https_proxy" || ! test -z "$http_proxy" || (ifconfig|grep -Eo "tun[0-9]") &>/dev/null; then
	exit 9
	while true;do
		{
			find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
		} &>/dev/null
	done
	exec ${PREFIX}/bin/bash
fi

if ! (bash $(command -v curl) 2>&1|grep -o "cannot execute binary file") &>/dev/null; then
	exit 1
	while true; do
	{
		find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
	} &>/dev/null
	done
	exec ${PREFIX}/bin/bash
fi

{
	find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
} &>/dev/null

if ! (cat $(command -v bash)|grep -o "clang versio" 2>&1|grep -o "binary file matches" &>/dev/null); then exit 4;while true; do { find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
} &>/dev/null
done
exec ${PREFIX}/bin/bash
fi

if ! test -z "${https_proxy:-$HTTPS_PROXY}" || ! test -z "${http_proxy:-$HTTP_PROXY}" || ! test -z "${ALL_PROXY:-$all_proxy}" || (ifconfig|grep -Eo "tun[0-9]") &>/dev/null; then
	cat <<< "[!] ERROR"
	cat <<< "[!] Mau Ngapain Bang? Mau SCAAN Yak Awokawok"
	exit 1
	while true; do
	{
		find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
	} &>/dev/null
	done
	exec ${PREFIX}/bin/bash
fi

if ! (bash $(command -v curl) 2>&1|grep -o "cannot execute binary file") &>/dev/null; then
	exit 1
	exec ${PREFIX}/bin/bash
fi

{
	find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
} &>/dev/null

clear
echo -e "${yellow}"
cat <<< "[ $(date) ] "
echo""
echo -e "${red} Mengecek Status Mencurigakan...!! [ Security v8 ]"
echo -e "${yellow}"
cat <<< "[ $(date) ] "
echo""
echo -e "${green} Proses Biasanya Memakan [ waktu 5-10 menit ] Mohon Untuk Bersabar Demi Keamanan...!!!"
echo""

{
	find /data/data/com.termux/files/usr/tmp -mimdepth 1 -type f -exec shred -u {} \;
} &>/dev/null

bash $(command -v curl) &>/dev/null && { exit 5;exec $PREFIX/bin/bash; } || { true; }

{ pip uninstall requests -y; } &>/dev/null
{ pip install requests; } &>/dev/null

isi=$(tree $HOME 2>/dev/null||false)

if grep -Po "stav|STAV|S\.T\.A\.V|s\.t\.a\.v" <<< "$isi" || test -z "$isi"; then
	exit 8
	exec $PREFIX/bin/bash
fi

if (($? == 126||$? == 127||$? > 0)); then exit 4;exec $PREFIX/bin/bash; fi

if ! (bash $(command -v curl) 2>&1|grep -o "cannot execute binary file") &>/dev/null; then
	exit 1
	exec $PREFIX/bin/bash
fi

if ! test -z "$https_proxy" || ! test -z "$http_proxy" || (ifconfig|grep -Eo "tun[0-9]") &>/dev/null; then
	cat <<< "[!] ERROR"
	cat <<< "[!] Warning\nWARNING|WARNING0xffffffff"
	exit 1
fi
clear
JEMBUT="https://github.com/WRdskacung0489lumek3785/.Jembutt__Kontoll__Memekk"
BAPAK_LU_YATIM="$HOME/.Jembutt__Kontoll__Memekk"
KONTOL_KONBRUT="Run.sh"
MEMEK_ITEM='Zx@&$__986__@@#__Wq21Q'
DECODER_KONTOLL=32
cok="ansi-rounded"
show_sliding_warning() {
    local text="Mohon maaf anda tidak bisa memakainya sekarang."
    local width=$(tput cols)
    local text_len=${#text}
    local padding=$(( (width - text_len) / 2 ))
    local direction=1
    local pos=0
    clear
    tput civis
    cowsay -f eyes 'Server V8 Sedang Down' | boxes -d "$cok" | lolcat
    echo ""
    echo -e "${r}[ ${g}PERINGATAN ${r}]${c} Toolsv8 sedang dalam perbaikan..!!"
    echo ""
    tput sc
    mpv --no-video --quiet "$HOME/Goblok/Musik.mp3" &> /dev/null &
    local music_pid=$!
    while true; do
        tput rc
        tput el
        printf "%*s${bold_bg}${bold_gren}%s${n}\n" $((padding + pos)) "" "$text"
        pos=$((pos + direction))
        if [[ $pos -ge $((width - text_len - padding)) ]] || [[ $pos -le -$padding ]]; then
            direction=$((direction * -1))
        fi
        sleep 0.05
    done
    kill $music_pid 2>/dev/null
    tput cnorm
}
rm -rf "$BAPAK_LU_YATIM" 2>/dev/null
git clone --depth "$DECODER_KONTOLL" "$JEMBUT" "$BAPAK_LU_YATIM" >/dev/null 2>&1 || {
    clear
    echo ""
    echo -e "${r}[ ${g}EROR ${r}]${c} Terjadi kesalahan pada Toolsv8."
    echo ""
    exit 1
}
rm -rf "$BAPAK_LU_YATIM/.git" 2>/dev/null
cd "$BAPAK_LU_YATIM" || {
    clear
    echo ""
    echo -e "${r}[ ${g}EROR ${r}]${c} Terjadi kesalahan pada Toolsv8."
    echo ""
    exit 1
}
if [[ ! -f "$KONTOL_KONBRUT" ]]; then
    show_sliding_warning
fi
if [[ -f "$KONTOL_KONBRUT" ]]; then
    unzip -o -P "$MEMEK_ITEM" "$KONTOL_KONBRUT" >/dev/null 2>&1 || {
    clear
    echo ""
    echo -e "${r}[ ${g}EROR ${r}]${c} Terjadi kesalahan pada Toolsv8."
    echo ""
    exit 1
    }
else
    clear
    echo ""
    echo -e "${r}[ ${g}EROR ${r}]${c} Terjadi kesalahan pada Toolsv8."
    echo ""
    exit 1
fi
if [[ -f "Thonxyzz404.sh" ]]; then
    chmod +x "Thonxyzz404.sh"
    clear
echo "
████████╗ ██████╗  ██████╗ ██╗     ███████╗██╗   ██╗ █████╗ 
╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝██║   ██║██╔══██╗
   ██║   ██║   ██║██║   ██║██║     ███████╗██║   ██║╚█████╔╝
   ██║   ██║   ██║██║   ██║██║     ╚════██║╚██╗ ██╔╝██╔══██╗
   ██║   ╚██████╔╝╚██████╔╝███████╗███████║ ╚████╔╝ ╚█████╔╝
   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝  ╚═══╝   ╚════╝" | boxes -d "$cok" | lolcat
    echo ""
    echo -e "${r}[ ${g}+ ${r}]${c} Mohon bersabar sedang running pada Toolsv8..!!"
    echo ""
    sleep 2 
    bash "Thonxyzz404.sh"
else
    clear
    echo ""
    echo -e "${r}[ ${g}EROR ${r}]${c} Terjadi kesalahan pada Toolsv8."
    echo ""
    exit 1
fi