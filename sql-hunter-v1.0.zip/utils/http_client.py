"""
HTTP Client with advanced features
"""

import requests
import random
import time
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class HTTPClient:
    def __init__(self, proxy=None, timeout=30):
        self.session = requests.Session()
        self.timeout = timeout
        self.proxy = proxy
        
        # Retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Set headers
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'close'
        })
        
        if proxy:
            self.session.proxies = {
                'http': proxy,
                'https': proxy
            }
    
    def get(self, url, params=None):
        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
            return {
                'status': response.status_code,
                'text': response.text,
                'headers': dict(response.headers),
                'length': len(response.text),
                'time': response.elapsed.total_seconds()
            }
        except Exception as e:
            return {'error': str(e)}
    
    def post(self, url, data=None):
        try:
            response = self.session.post(url, data=data, timeout=self.timeout)
            return {
                'status': response.status_code,
                'text': response.text,
                'headers': dict(response.headers),
                'length': len(response.text),
                'time': response.elapsed.total_seconds()
            }
        except Exception as e:
            return {'error': str(e)}
