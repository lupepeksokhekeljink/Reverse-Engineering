#!/usr/bin/env python3
"""
SQL-HUNTER v1.0 - Advanced SQL Injection Scanner
GrayHat Security Terminal - TCCI Cybercrime Indonesia
"""

import sys
import os
import argparse
import textwrap


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from core.colors import Colors
    from core.logger import Logger
    from modules.scanner import Scanner
    from modules.detector import Detector
    from utils.http_client import HTTPClient
except ImportError as e:
    print(f"[!] Import Error: {e}")
    sys.exit(1)

class SQLHunter:
    def __init__(self):
        self.colors = Colors()
        self.logger = Logger()
        
        # Banner
        self.banner = f"""{self.colors.CYAN}
                                    ⣀⡠⢤⡀
                                 ⢀⡴⠟⠃  ⠙⣄
                                ⣠⠋      ⠘⣆
                              ⢠⠾⢛⠒       ⢸⡆
                              ⣿⣶⣄⡈⠓⢄⠠⡀   ⣄⣷
                             ⢀⣿⣷ ⠈⠱⡄⠑⣌⠆  ⡜⢻
                             ⢸⣿⡿⠳⡆⠐⢿⣆⠈⢿  ⡇⠘⡆
                              ⢿⣿⣷⡇  ⠈⢆⠈⠆⢸  ⢣
                              ⠘⣿⣿⣿⣧  ⠈⢂ ⡇  ⢨⠓⣄
                               ⣸⣿⣿⣿⣦⣤⠖⡏⡸ ⣀⡴⠋ ⠈⠢⡀
                             ⢠⣾⠁⣹⣿⣿⣿⣷⣾⠽⠖⠊⢹⣀⠄   ⠈⢣⡀
                             ⡟⣇⣰⢫⢻⢉⠉ ⣿⡆  ⡸⡏      ⢇
                            ⢨⡇⡇⠈⢸⢸⢸  ⡇⡇  ⠁⠻⡄⡠⠂   ⠘
⢤⣄                         ⢠⠛⠓⡇ ⠸⡆⢸ ⢠⣿    ⣰⣿⣵⡆
⠈⢻⣷⣦⣀                     ⣠⡿⣦⣀⡇ ⢧⡇  ⢺⡟   ⢰⠉⣰⠟⠊⣠⠂ ⡸
  ⢻⣿⣿⣷⣦⣀                 ⣠⢧⡙⠺⠿⡇ ⠘⠇  ⢸⣧  ⢠⠃⣾⣌⠉⠩⠭⠍⣉⡇
   ⠻⣿⣿⣿⣿⣿⣦⣀            ⣠⣞⣋ ⠈ ⡳⣧     ⢸⡏  ⡞⢰⠉⠉⠉⠉⠉⠓⢻⠃
    ⠹⣿⣿⣿⣿⣿⣿⣷⡄  ⢀⣀⠠⠤⣤⣤⠤⠞⠓⢠⠈⡆ ⢣⣸⣾⠆     ⢀⣀⡼⠁⡿⠈⣉⣉⣒⡒⠢⡼
     ⠘⣿⣿⣿⣿⣿⣿⣿⣎⣽⣶⣤⡶⢋⣤⠃⣠⡦⢀⡼⢦⣾⡤⠚⣟⣁⣀⣀⣀⣀ ⣀⣈⣀⣠⣾⣅ ⠑⠂⠤⠌⣩⡇
      ⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡁⣺⢁⣞⣉⡴⠟⡀   ⠁⠸⡅ ⠈⢷⠈⠏⠙ ⢹⡛ ⢉   ⣀⣀⣼⡇
        ⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⡟⢡⠖⣡⡴⠂⣀⣀⣀⣰⣁⣀⣀⣸    ⠈⠁  ⠈ ⣠⠜⠋⣠⠁
           ⠙⢿⣿⣿⣿⡟⢿⣿⣿⣷⡟⢋⣥⣖⣉ ⠈⢁⡀⠤⠚⠿⣷⡦⢀⣠⣀⠢⣄⣀⡠⠔⠋⠁ ⣼⠃
             ⠈⠻⣿⣿⡄⠈⠻⣿⣿⢿⣛⣩⠤⠒⠉⠁     ⠉⠒⢤⡀⠉⠁     ⢀⡿
               ⠈⠙⢿⣤⣤⠴⠟⠋⠉             ⠈⠑⠤     ⢩⠇
                  ⠈
{self.colors.RED}
╔════════════════════════════════════════════╗
║           GRAYHAT SECURITY TERMINAL        ║
║              TCCI CYBERCRIME INDONESIA     ║
╚════════════════════════════════════════════╝
{self.colors.YELLOW}
[!] SQL-HUNTER v1.0 - Advanced SQL Injection Scanner
[!] Author: MR•Zeeone-Grayhat
[!] Legal Disclaimer: For authorized testing only!
{self.colors.RESET}"""
    
    def show_banner(self):
        """Show the awesome banner"""
        print(self.banner)
    
    def show_usage(self):
        """Show usage like sqlmap"""
        print(f"""
{self.colors.CYAN}Usage:{self.colors.RESET}
  python sql-hunter.py [options]

{self.colors.YELLOW}Basic Options:{self.colors.RESET}
  -h, --help            Show basic help message and exit
  -hh                   Show advanced help message and exit
  --version             Show program's version number and exit
  -v VERBOSE            Verbosity level: 0-6 (default 1)

{self.colors.YELLOW}Target:{self.colors.RESET}
  At least one of these options has to be provided to define the target(s)

  -u URL, --url=URL     Target URL (e.g. "http://www.site.com/vuln.php?id=1")
  --data=DATA           Data string to be sent via POST
  --cookie=COOKIE       HTTP Cookie header value

{self.colors.YELLOW}Request:{self.colors.RESET}
  These options can be used to specify how to connect to the target URL

  --method=METHOD       Force usage of given HTTP method (e.g. PUT)
  --proxy=PROXY         Use a proxy to connect to the target URL
  --tor                 Use Tor anonymity network
  --delay=DELAY         Delay in seconds between each HTTP request

{self.colors.YELLOW}Injection:{self.colors.RESET}
  These options can be used to specify which parameters to test for,
  provide custom injection payloads and optional tampering scripts

  -p TESTPARAMETER      Testable parameter(s)
  --dbms=DBMS           Force back-end DBMS to this value
  --technique=TECH      SQL injection techniques to use (default "BEUST")
                        B: Boolean-based blind
                        E: Error-based
                        U: Union query
                        S: Stacked queries
                        T: Time-based blind

{self.colors.YELLOW}Detection:{self.colors.RESET}
  These options can be used to customize the detection phase

  --level=LEVEL         Level of tests to perform (1-5, default 1)
  --risk=RISK           Risk of tests to perform (1-3, default 1)

{self.colors.YELLOW}Enumeration:{self.colors.RESET}
  These options can be used to enumerate the back-end database
  management system information, structure and data

  -a, --all             Retrieve everything
  -b, --banner          Retrieve DBMS banner
  --current-user        Retrieve DBMS current user
  --current-db          Retrieve DBMS current database
  --dbs                 Enumerate DBMS databases
  --tables              Enumerate DBMS database tables
  --columns             Enumerate DBMS database table columns
  --dump                Dump DBMS database table entries
  --dump-all            Dump all DBMS databases tables entries

{self.colors.YELLOW}Examples:{self.colors.RESET}
  python sql-hunter.py -u "http://www.site.com/vuln.php?id=1"
  python sql-hunter.py -u "http://www.site.com/vuln.php" --data="id=1"
  python sql-hunter.py -u "http://www.site.com/vuln.php?id=1" --dbs
  python sql-hunter.py -u "http://www.site.com/vuln.php?id=1" --dump -D testdb -T users

{self.colors.RED}[!] Legal Disclaimer:{self.colors.RESET}
  This tool is for authorized security testing only.
  Unauthorized use is illegal and strictly prohibited.
""")
    
    def show_advanced_help(self):
        """Show advanced help like sqlmap -hh"""
        self.show_banner()
        print(f"""
{self.colors.CYAN}Advanced Help:{self.colors.RESET}

{self.colors.YELLOW}Optimization:{self.colors.RESET}
  These options can be used to optimize the performance of sql-hunter

  --threads=THREADS     Max number of concurrent HTTP(s) requests (default 1)
  --batch               Never ask for user input, use the default behavior

{self.colors.YELLOW}Tamper Scripts:{self.colors.RESET}
  Use tamper scripts to bypass WAF/IDS

  --tamper=TAMPER       Use given script(s) for tampering injection data
  --list-tampers        Display list of available tamper scripts

{self.colors.YELLOW}Miscellaneous:{self.colors.RESET}
  --check-tor           Check if Tor is used properly
  --wizard              Simple wizard interface for beginner users
  --purge               Safely remove all content from output directory
  --dependencies        Check for missing dependencies

{self.colors.GREEN}Note:{self.colors.RESET}
  For full documentation, visit: https://github.com/grayhat/sql-hunter
""")
    
    def parse_arguments(self):
        """Parse command line arguments like sqlmap"""
        parser = argparse.ArgumentParser(
            description='SQL-HUNTER - Advanced SQL Injection Scanner',
            usage='python sql-hunter.py [options]',
            add_help=False,
            formatter_class=argparse.RawTextHelpFormatter
        )
        
        
        basic = parser.add_argument_group('Basic Options')
        basic.add_argument('-h', '--help', action='store_true', 
                         help='Show basic help message and exit')
        basic.add_argument('-hh', action='store_true', 
                         help='Show advanced help message and exit')
        basic.add_argument('--version', action='store_true', 
                         help="Show program's version number and exit")
        basic.add_argument('-v', type=int, choices=range(0, 7), default=1,
                         help='Verbosity level: 0-6 (default 1)')
        
        
        target = parser.add_argument_group('Target')
        target.add_argument('-u', '--url', 
                          help='Target URL (e.g. "http://www.site.com/vuln.php?id=1")')
        target.add_argument('--data', 
                          help='Data string to be sent via POST')
        target.add_argument('--cookie', 
                          help='HTTP Cookie header value')
        
        
        request = parser.add_argument_group('Request')
        request.add_argument('--method', choices=['GET', 'POST', 'PUT', 'DELETE'], 
                           default='GET', help='Force usage of given HTTP method')
        request.add_argument('--proxy', 
                           help='Use a proxy to connect to the target URL')
        request.add_argument('--tor', action='store_true', 
                           help='Use Tor anonymity network')
        request.add_argument('--delay', type=float, 
                           help='Delay in seconds between each HTTP request')
        
        
        injection = parser.add_argument_group('Injection')
        injection.add_argument('-p', 
                             help='Testable parameter(s)')
        injection.add_argument('--dbms', 
                             choices=['MySQL', 'PostgreSQL', 'Microsoft SQL Server', 'Oracle', 'SQLite'],
                             help='Force back-end DBMS to this value')
        injection.add_argument('--technique', default='BEUST',
                             help='SQL injection techniques to use (default "BEUST")')
        
        
        detection = parser.add_argument_group('Detection')
        detection.add_argument('--level', type=int, choices=range(1, 6), default=1,
                             help='Level of tests to perform (1-5, default 1)')
        detection.add_argument('--risk', type=int, choices=range(1, 4), default=1,
                             help='Risk of tests to perform (1-3, default 1)')
        
        
        enum = parser.add_argument_group('Enumeration')
        enum.add_argument('-a', '--all', action='store_true',
                        help='Retrieve everything')
        enum.add_argument('-b', '--banner', action='store_true',
                        help='Retrieve DBMS banner')
        enum.add_argument('--current-user', action='store_true',
                        help='Retrieve DBMS current user')
        enum.add_argument('--current-db', action='store_true',
                        help='Retrieve DBMS current database')
        enum.add_argument('--dbs', action='store_true',
                        help='Enumerate DBMS databases')
        enum.add_argument('--tables', action='store_true',
                        help='Enumerate DBMS database tables')
        enum.add_argument('--columns', action='store_true',
                        help='Enumerate DBMS database table columns')
        enum.add_argument('--dump', action='store_true',
                        help='Dump DBMS database table entries')
        enum.add_argument('--dump-all', action='store_true',
                        help='Dump all DBMS databases tables entries')
        
        
        optimization = parser.add_argument_group('Optimization')
        optimization.add_argument('--threads', type=int, default=1,
                                help='Max number of concurrent HTTP(s) requests (default 1)')
        optimization.add_argument('--batch', action='store_true',
                                help='Never ask for user input, use the default behavior')
        
        
        misc = parser.add_argument_group('Miscellaneous')
        misc.add_argument('--check-tor', action='store_true',
                         help='Check if Tor is used properly')
        misc.add_argument('--wizard', action='store_true',
                         help='Simple wizard interface for beginner users')
        
        return parser.parse_args()
    
    def show_version(self):
        """Show version information"""
        print(f"""
{self.colors.CYAN}SQL-HUNTER v1.0{self.colors.RESET}

{self.colors.YELLOW}Credits:{self.colors.RESET}
  GrayHat Security Team
  TCCI Cybercrime Indonesia

{self.colors.YELLOW}License:{self.colors.RESET}
  GNU General Public License v3.0

{self.colors.YELLOW}Website:{self.colors.RESET}
  https://github.com/grayhat/sql-hunter
""")
    
    def run_wizard(self):
        """Run wizard mode for beginners"""
        print(f"\n{self.colors.CYAN}SQL-HUNTER Wizard Mode{self.colors.RESET}")
        print(f"{self.colors.YELLOW}====================={self.colors.RESET}\n")
        
        target = input(f"{self.colors.CYAN}[?] Enter target URL: {self.colors.RESET}")
        
        if not target:
            print(f"{self.colors.RED}[!] No URL provided{self.colors.RESET}")
            return
        
        print(f"\n{self.colors.GREEN}[+] Starting scan with wizard mode...{self.colors.RESET}")
        print(f"{self.colors.YELLOW}[*] Target: {target}{self.colors.RESET}")
        
        # Here you would call the actual scanner
        self.logger.info("Wizard mode activated")
        self.logger.success("Scan started successfully!")
    
    def run_scan(self, args):
        """Run actual scan"""
        if not args.url:
            print(f"{self.colors.RED}[!] Error: No target URL specified{self.colors.RESET}")
            print(f"{self.colors.YELLOW}[*] Use -u option to specify target URL{self.colors.RESET}")
            return
        
        print(f"\n{self.colors.GREEN}[*] Starting SQL-HUNTER scan{self.colors.RESET}")
        print(f"{self.colors.CYAN}[*] Target URL: {args.url}{self.colors.RESET}")
        
        if args.data:
            print(f"{self.colors.CYAN}[*] POST data: {args.data}{self.colors.RESET}")
        
        print(f"{self.colors.CYAN}[*] HTTP method: {args.method}{self.colors.RESET}")
        print(f"{self.colors.CYAN}[*] Level: {args.level}, Risk: {args.risk}{self.colors.RESET}")
        print(f"{self.colors.CYAN}[*] Technique(s): {args.technique}{self.colors.RESET}")
        
        
        print(f"\n{self.colors.YELLOW}[*] Loading modules...{self.colors.RESET}")
        print(f"{self.colors.YELLOW}[*] Checking target availability...{self.colors.RESET}")
        print(f"{self.colors.YELLOW}[*] Initializing payloads...{self.colors.RESET}")
        
        
        http_client = HTTPClient(proxy=args.proxy)
        detector = Detector(http_client, self.logger)
        scanner = Scanner(
            target_url=args.url,
            http_client=http_client,
            detector=detector,
            logger=self.logger,
            options=vars(args)
        )
        
        
        if scanner.start():
            summary = scanner.get_summary()
            
            print(f"\n{self.colors.GREEN}{'='*60}{self.colors.RESET}")
            print(f"{self.colors.CYAN}{'SCAN SUMMARY':^60}{self.colors.RESET}")
            print(f"{self.colors.GREEN}{'='*60}{self.colors.RESET}")
            
            for key, value in summary.items():
                print(f"{key:30}: {value}")
            
            print(f"{self.colors.GREEN}{'='*60}{self.colors.RESET}")
            print(f"\n{self.colors.YELLOW}[!] For real SQL injection detection, implement detection logic{self.colors.RESET}")
    
    def run(self):
        """Main execution method"""
        try:
            
            args = self.parse_arguments()
            
            
            if args.version:
                self.show_version()
                return
            
            if args.hh:
                self.show_advanced_help()
                return
            
            if args.help:
                self.show_usage()
                return
            
            if args.wizard:
                self.run_wizard()
                return
            
            
            if not args.batch:
                self.show_banner()
            
            
            self.run_scan(args)
            
        except KeyboardInterrupt:
            print(f"\n\n{self.colors.YELLOW}[!] Scan interrupted by user{self.colors.RESET}")
        except Exception as e:
            print(f"\n{self.colors.RED}[!] Error: {str(e)}{self.colors.RESET}")

def main():
    """Entry point"""
    hunter = SQLHunter()
    hunter.run()

if __name__ == "__main__":
    main()
