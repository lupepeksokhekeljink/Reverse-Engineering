# SQL-HUNTER 🔍

Advanced SQL Injection Scanner - GrayHat Security Terminal

## Features
- Multiple SQL injection technique detection
- DBMS fingerprinting
- Data enumeration and extraction
- WAF evasion with tamper scripts
- Custom banner and interface

## Installation
```bash
git clone https://github.com/zeeoneofc112-dev/sql-hunter
cd sql-hunter
pip install -r requirements.txt
