"""
Advanced Scanner with URL parsing
"""

from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

class Scanner:
    def __init__(self, target_url, http_client, detector, logger, options):
        self.target_url = target_url
        self.http = http_client
        self.detector = detector
        self.logger = logger
        self.options = options
        
        # Parse URL
        self.parsed_url = urlparse(target_url)
        self.base_url = f"{self.parsed_url.scheme}://{self.parsed_url.netloc}{self.parsed_url.path}"
        self.params = parse_qs(self.parsed_url.query)
        
        # Results
        self.results = {
            'vulnerable': False,
            'vulnerabilities': [],
            'parameters_tested': 0,
            'techniques_found': []
        }
    
    def start(self):
        """Start comprehensive scan"""
        self.logger.info(f"Starting scan: {self.target_url}")
        
        if not self.params:
            self.logger.error("No parameters found in URL")
            return False
        
        # Test each parameter
        for param_name in self.params:
            original_value = self.params[param_name][0]
            self.logger.info(f"Testing parameter: {param_name}")
            
            # Test different techniques
            techniques = [
                ('Boolean-based', self.detector.test_boolean_blind),
                ('Time-based', self.detector.test_time_based),
                ('Error-based', self.detector.test_error_based)
            ]
            
            for tech_name, tech_func in techniques:
                try:
                    if tech_func(self.base_url, param_name, original_value):
                        self.results['vulnerable'] = True
                        self.results['vulnerabilities'].append({
                            'parameter': param_name,
                            'technique': tech_name,
                            'payload': 'DEMO PAYLOAD'
                        })
                        self.results['techniques_found'].append(tech_name)
                except Exception as e:
                    self.logger.error(f"Error testing {tech_name}: {e}")
            
            self.results['parameters_tested'] += 1
        
        return True
    
    def get_summary(self):
        """Get detailed scan summary"""
        summary = {
            'Target URL': self.target_url,
            'Parameters Tested': self.results['parameters_tested'],
            'Status': 'VULNERABLE' if self.results['vulnerable'] else 'NOT VULNERABLE',
            'Vulnerabilities Found': len(self.results['vulnerabilities']),
            'Techniques Detected': ', '.join(set(self.results['techniques_found'])) or 'None'
        }
        
        if self.results['vulnerabilities']:
            summary['Vulnerable Parameters'] = ', '.join(
                [v['parameter'] for v in self.results['vulnerabilities']]
            )
        
        return summary

