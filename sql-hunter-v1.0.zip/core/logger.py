"""
Enhanced Logger
"""
from .colors import Colors

class Logger:
    def __init__(self, verbose=True):
        self.colors = Colors()
        self.verbose = verbose
    
    def info(self, message):
        if self.verbose:
            print(f"{self.colors.info('[∗]')} {message}")
    
    def success(self, message):
        print(f"{self.colors.success('[✓]')} {message}")
    
    def error(self, message):
        print(f"{self.colors.error('[✗]')} {message}")
    
    def warning(self, message):
        print(f"{self.colors.warning('[!]')} {message}")
    
    def debug(self, message):
        if self.verbose:
            print(f"{self.colors.CYAN}[DEBUG]{self.colors.RESET} {message}")

