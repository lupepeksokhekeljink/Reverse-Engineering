"""
Tamper script: Convert to lowercase
"""

def tamper(payload, **kwargs):
    """
    Replaces each keyword character with lower case value
    
    Example:
    Input: UNION SELECT
    Output: union select
    """
    
    keywords = [
        'UNION', 'SELECT', 'INSERT', 'UPDATE', 'DELETE', 
        'DROP', 'FROM', 'WHERE', 'AND', 'OR', 'LIKE',
        'ORDER BY', 'GROUP BY', 'HAVING', 'LIMIT',
        'OFFSET', 'JOIN', 'INNER', 'OUTER', 'LEFT',
        'RIGHT', 'FULL', 'CROSS', 'NATURAL'
    ]
    
    for keyword in keywords:
        if keyword in payload.upper():
            payload = payload.replace(keyword, keyword.lower())
    
    return payload
