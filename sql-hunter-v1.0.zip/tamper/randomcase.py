"""
Tamper script: Random case
"""

import random

def tamper(payload, **kwargs):
    """
    Replaces each keyword character with random case
    
    Example:
    Input: UNION SELECT
    Output: UnIoN sElEcT
    """
    
    keywords = [
        'UNION', 'SELECT', 'INSERT', 'UPDATE', 'DELETE', 
        'DROP', 'FROM', 'WHERE', 'AND', 'OR', 'LIKE',
        'ORDER', 'BY', 'GROUP', 'HAVING', 'LIMIT',
        'OFFSET', 'JOIN', 'INNER', 'OUTER', 'LEFT',
        'RIGHT', 'FULL', 'CROSS', 'NATURAL'
    ]
    
    for keyword in keywords:
        if keyword.upper() in payload.upper():
            
            start = 0
            while True:
                index = payload.upper().find(keyword.upper(), start)
                if index == -1:
                    break
                
                
                random_case = ''.join(
                    random.choice([c.upper(), c.lower()]) for c in keyword
                )
                
                
                payload = payload[:index] + random_case + payload[index + len(keyword):]
                start = index + len(keyword)
    
    return payload
