#Sabtu - 1 - November - 2025
#Decode By Andrax Dev
#anjay manual njir :v
#Tools Decode By Andrax C2

import re
import time
import string
import random
import os

m = "\033[1;31m"
i = "\033[1;32m"
c = "\033[1;36m"
y = "\033[1;33m"
p = "\033[1;37m"
r = "\033[0m"

def bersihkan_layar():
    os.system('cls' if os.name == 'nt' else 'clear')

def cek_kekuatan_password(password):
    skor = 0
    saran = []
    
    panjang = len(password)
    if panjang >= 12:
        skor += 25
    elif panjang >= 8:
        skor += 15
    elif panjang >= 6:
        skor += 5
    else:
        saran.append("Password terlalu pendek (minimum 8 karakter)")
    
    if re.search(r'[A-Z]', password):
        skor += 20
    else:
        saran.append("Tambahkan huruf besar (A-Z)")
    
    if re.search(r'[a-z]', password):
        skor += 20
    else:
        saran.append("Tambahkan huruf kecil (a-z)")
    
    if re.search(r'\d', password):
        skor += 20
    else:
        saran.append("Tambahkan angka (0-9)")
    
    if re.search(r'[!@#$%^&*(),.?":{}|<>_\-+=\[\]\\\/~`]', password):
        skor += 15
    else:
        saran.append("Tambahkan karakter spesial (!@#$%^&*)")
    
    karakter_unik = len(set(password))
    if karakter_unik >= panjang * 0.7:
        skor += 10
    
    pola_umum = ['123', 'abc', 'password', 'qwerty', '111', '000']
    for pola in pola_umum:
        if pola.lower() in password.lower():
            skor -= 10
            saran.append(f"Hindari pola umum seperti '{pola}'")
    
    skor = min(100, max(0, skor))
    
    return skor, saran

def validasi_email(email):
    pola = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pola, email) is not None

def buat_password(panjang=16):
    huruf_kecil = string.ascii_lowercase
    huruf_besar = string.ascii_uppercase
    angka = string.digits
    spesial = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    password = [
        random.choice(huruf_kecil),
        random.choice(huruf_besar),
        random.choice(angka),
        random.choice(spesial)
    ]
    
    semua_karakter = huruf_kecil + huruf_besar + angka + spesial
    password += random.choices(semua_karakter, k=panjang - 4)
    
    random.shuffle(password)
    
    return ''.join(password)

def tampilkan_status(skor):
    if skor >= 80:
        return f"{p} SANGAT AMAN", p
    elif skor >= 60:
        return f"{p} AMAN", p
    elif skor >= 40:
        return f"{p} CUKUP AMAN", p
    else:
        return f"{p} LEMAH", p

def menu_cek_password():
    bersihkan_layar()
    print(f"""{m}
⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄
⠀⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢲⣿⡇
⢸⣿⣿⠀⠀⢀⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⡆⠀⠀⣹⣿⡇
⢸⣿⣿⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣇⠀⠀⢸⣿⡇
⢸⣿⡟⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣯⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⢸⣿⣇
⢸⣿⣿⣀⠀⠸⣿⣷⣄⡀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⢀⣠⣴⣿⠿⠀⣀⣼⣿⡿
⠀⠈⠙⠿⣿⣶⣤⡉⠻⢿⣷⣦⣀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⢀⣤⣶⣿⠿⠋⣡⣴⣿⡿⠛⠉⠀
⠀⠀⠀⠀⠀⠉⢿⣿⡇⠀⠈⣿⣿⡇⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⣿⣿⠋⠀⠠⣿⣿⠋⠁⠀⠀⠀⠀
⠀⠀⠀⠀⣀⣤⣾⣿⠇⢀⣠⣿⣿⠇⠀⠀⠘⠿⣿⣿⣿⣿⣿⡿⠏⠀⠀⠀⣿⣿⣤⡀⠘⢿⣿⣦⣀⠀⠀⠀⠀
⠀⢀⣤⣾⣿⠟⠋⣠⣴⣿⡿⠛⠁⠀⣠⣾⣦⣄⡀⠙⠻⠋⠁⣀⣴⣾⣦⡀⠀⠙⠻⣿⣷⣄⠈⠻⢿⣷⣦⣀⠀
⠀⣿⣿⠋⠀⠀⠀⣿⣿⡇⠀⠀⠀⣾⣿⣿⣿⣿⣿⣷⣦⣶⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⣿⣿⠀⠀⠀⠈⢻⣿⡇
⠀⣿⣿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣿⣿⠀⠀⠀⠀⣹⣿⡇
⠀⣿⣿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣿⣿⠀⠀⠀⠀⢼⣿⡇
⠀⣿⣿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣿⣿⠀⠀⠀⠀⢺⣿⡇
⠀⣿⣿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣿⣿⠀⠀⠀⠀⣹⣿⡇
⠀⣿⣿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣿⣿⠀⠀⠀⠀⢺⣿⡇
⠀⣿⣿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⠉⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠁⠀⠀⠀⣿⣿⠀⠀⠀⠀⢻⣿⡇
⠀⣿⣿⠀⠀⠀⠀⡿⠁⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠈⠻⠀⠀⠀⠀⢻⣿⡇
⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⢿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇
⠀⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⡇
⠀⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃
""")
    
    email = input(f"{m}[{p}?{m}]{p} Masukkan Alamat Email {m}:{p} ")
    
    if not validasi_email(email):
        print(f"\n{m}[{p}!{m}]{p} Format email tidak valid{m}!{r}")
        input(f"\n\033[107m{m}Enter Untuk Kembali{r}")
        return
    
    password = input(f"{m}[{p}?{m}]{p} Masukkan Password {m}:{p} ")
    
    print(f"\n\033[107m{m}Hasil Checking Password\033[0m\n")
    
    skor, saran = cek_kekuatan_password(password)
    status, warna = tampilkan_status(skor)
    
    print(f"{m}[{p}+{m}] {p}Alamat Email {m}:{p} {email}")
    print(f"{m}[{p}+{m}] {p}Password {m}: {p}{'*' * len(password)}")
    print(f"\n{m}[{p}+{m}] {p}Nilai Keamanan Password {m}:{p} {warna}{skor}{m}/{p}100{r}")
    print(f"{m}[{p}+{m}] {p}Status {m}: {p}{status}\n")
    
    if saran:
        print(f"{m}[{p}!{m}]{p} Saran Perbaikan{m}:{r}")
        for idx, suggestion in enumerate(saran, 1):
            print(f"    {p}{idx}{m}. {p}{suggestion}")
    
    if skor < 60:
        print(f"\n{m}[{p}!{m}] {p}Harap Ubah Password Kamu Demi Keamanan Akun{r}")
        print(f"{m}[{p}!{m}]{p} Yang Menyimpan Data Akun & Informasi Penting‼️{r}")
    else:
        print(f"\n{m}[{p}✓{m}] {p}Password Kamu Sudah Cukup Aman{m}!{r}")
    
    input(f"\n\033[107m\033[1;31mEnter Untuk Kembali\033[0m")

def menu_buat_password():
    bersihkan_layar()
    print(f"""{m}
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣤⣤⣀⣠⣶⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⡿⠟⠛⠉⠉⠉⠉⠉⠉⠛⠿⣝⡢⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⢞⡿⠋⢀⡴⢋⡀⠀⠀⠀⠀⠀⠀⠀⡈⠙⢮⣷⢤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⢣⡟⠁⠀⠛⠴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⣄⠉⠙⠛⠛⠿⣶⣄⠀⠀⠀⢀⣀⡤⡤⢄⣀⠀⠀⠀⠀
⠀⣀⣠⣠⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⡿⠀⠀⠀⢀⣤⣤⣄⠀⠀⠀⢀⣤⣤⡀⠀⠀⠘⣶⣶⠾⠷⠶⠾⡿⠀⠀⡴⣻⠾⠋⠉⠻⣯⡳⡄⠀⠀
⢰⣿⠋⠙⠻⣝⢦⡀⠀⠀⠀⠀⠀⠀⢸⣿⠃⠀⠀⠀⣾⣿⣿⣿⡆⠀⢀⣾⣿⣿⣿⡆⠀⠀⢹⣿⠀⠀⠀⠀⠀⢠⣾⡿⠋⠀⠀⠀⠀⠈⢷⣱⡀⠀
⢸⣿⠀⠀⠀⠈⠳⣿⣦⡀⠀⠀⠀⠀⣿⡿⠀⠀⠀⠀⣿⣿⣿⣿⣷⠀⢸⣿⣿⣿⣿⣷⡀⠀⢸⣾⡄⠀⠀⠀⢀⣾⡟⠁⠀⠀⠀⢀⡀⠀⠈⣿⣧⠀
⠸⣿⡀⠀⠀⢠⠀⠈⠻⣿⣦⡀⠀⢸⣿⠇⠀⠀⢀⠀⢿⣿⣿⣿⡇⠀⠘⣿⣿⣿⣿⠇⢷⠀⠈⣿⢷⠀⠀⢀⣾⡿⠁⠀⠀⡖⠀⣾⠁⠀⠀⢹⣿⡀
⠀⢿⣧⠀⠀⠀⢧⠀⠀⠈⠳⣽⣶⣾⡟⠀⠀⢠⠏⡀⠈⠛⠛⠋⠀⠀⠀⠈⠻⠟⠋⠀⠘⣇⠀⠘⢯⣝⣶⣾⡿⠁⠀⠀⢸⠃⠀⡇⠀⠀⠀⠸⣿⡇
⠀⠈⢿⣇⠀⠀⠘⣇⠀⠀⠀⠀⠉⠉⠀⠀⣰⢏⡼⠁⠀⠀⠀⠀⢰⣿⣷⠀⠀⠀⠀⠀⠰⣌⠧⠀⠀⠈⠉⠁⠀⠀⠀⠀⡟⠀⠀⠀⠀⠀⠀⠀⣿⡇
⠀⠀⢸⣿⠀⠀⠀⢻⢀⡀⠀⠀⠀⠀⠀⠈⠁⠈⠀⠀⠀⠀⠀⠀⠘⠿⠟⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⢸⣇⣴⡶⣶⢶⣤⣀⠀⣿⡇
⠀⠀⢸⡿⠀⠀⠀⠘⡇⢧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡟⠁⠀⢻⣷⣿⣿⣿⣿⠁
⠀⢠⣿⠇⠀⠀⠀⠀⠣⢸⡀⠘⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⢶⣄⣸⣿⣏⣿⣿⠿⠁
⠀⣼⡟⠀⠀⣀⣀⣀⡀⠀⣇⠀⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡄⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⡜⡇⠀⠀⠀
⠀⡏⣣⣴⣿⡿⢻⡏⠛⢿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣼⡄⠀⠀
⠀⠹⣟⣿⢿⣿⣾⠀⠀⣠⣿⠂⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄⠀⠀⠀⠀⠀⡼⠀⠀⠀⢠⠇⠀⠀⠀⠀⢀⣴⡟⡼⠁⠀⠀
⠀⠀⠈⠉⣹⢻⣷⡶⠟⠋⠁⠀⡀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡴⠋⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⣸⣤⣶⣶⣶⣾⣛⡵⠚⠁⠀⠀⠀
⠀⠀⠀⠀⡻⣿⡁⠀⠀⠀⠀⢸⡇⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠉⠓⠒⠉⠁⠀⠀⣰⠃⠀⠀⠀⢸⠇⠀⠀⠀⣿⠏⠀⢾⡟⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠛⠿⢿⣿⣿⣶⣶⣾⡇⠀⠀⠀⡇⠀⠀⠀⠀⢆⠀⠀⠀⠀⠀⠀⠀⠀⣴⠃⠀⠀⠀⠀⣸⠀⠀⠀⠀⢿⣆⡀⢸⣿⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣤⣿⠃⠀⠀⠀⡇⠀⠀⡄⠀⠈⠳⣄⠀⠀⠀⠀⣠⠞⠁⠀⢠⠃⠀⠀⣿⠀⠀⠀⠀⠀⠉⠛⢿⣿⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣷⣿⠋⠁⠀⠀⠀⢸⡇⠀⠀⠸⡄⠀⠀⠈⠙⠒⠒⠋⠁⠀⠀⠀⡞⠀⠀⠀⣿⠀⠀⠀⠀⠀⣀⣠⣼⢿⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢯⣟⡷⢶⣤⣤⣀⢸⡇⠀⠀⠀⢣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠃⠀⠀⠀⣿⠾⠛⢻⣿⠿⠭⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⢳⣿⠙⣿⠃⠀⠀⠀⠸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⡾⠀⠀⠀⠀⠻⢷⣤⣼⣯⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡾⠛⠀⠀⠀⠀⠀⣧⠀⠀⠀⠀⠀⠀⠀⠀⢠⡇⠀⠀⠀⠀⠀⠀⠙⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣟⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⢸⡃⣀⣀⠀⠀⠀⠀⣠⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣷⠦⣤⣤⠤⠤⣤⣿⣄⡀⠀⠀⠀⠀⠀⠀⢼⡟⠛⣿⣿⠿⠶⠾⠿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠉⠉⠉⠛⢿⡿⣷⡀⠀⠀⠀⠀⠈⠻⣾⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣾⣷⠀⠀⠀⠀⠀⠀⢹⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣟⡟⠀⠀⠀⠀⠀⣠⡿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢨⣿⡇⠀⠀⠀⢀⡾⢻⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣏⣧⠀⠀⠀⣾⣱⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢮⣷⣄⣸⣷⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⠟
""")
    
    try:
        panjang = input(f"{m}[{p}?{m}]{p} Masukkan Panjang Password {m}:{p} ")
        panjang = int(panjang) if panjang else 16
        
        if panjang < 8:
            print(f"\n{m}[{p}!{m}]{p} Panjang password minimal 8 karakter{m}!{r}")
            input(f"\n\033[107m{m}Enter Untuk Kembali\033[0m")
            return
        
        print(f"\n\033[107m{m}Berhasil Membuat Password\033[0m\n")
        
        for idx in range(5):
            pwd = buat_password(panjang)
            skor, _ = cek_kekuatan_password(pwd)
            status, warna = tampilkan_status(skor)
            print(f"    {p}{idx+1}{m}. {p}{pwd} {m}- {p}{warna}{skor}{m}/{p}100{r}{m} [{p}+{m}]{p} {status}")
        
        print(f"\n{m}[{p}!{m}]{p} Simpan Password Ditempat Yang Aman")
        
    except ValueError:
        print(f"\n{m}[{p}!{m}]{p} Input Tidak Valid{m}!")
    
    input(f"\n\033[107m\033[1;31mEnter Untuk Kembali\033[0m")

def saluran_menu3():
    url = "https://whatsapp.com/channel/0029VbBLBZ80lwgrRDEnyV0v"

    if "termux" in os.getenv("PREFIX", "").lower():
        os.system(f"termux-open-url '{url}'")
    elif platform.system() == "Linux":
        os.system(f"xdg-open '{url}'")
    elif platform.system() == "Windows":
        os.system(f"start {url}")
    elif platform.system() == "Darwin":
        os.system(f"open {url}")
    else:
        import webbrowser
        webbrowser.open(url)

def saluran_menu4():
    print(f"{m}[{p}+{m}]{p} Ikuti Channel WhatsApp Saya Untuk Tools Lainnya\033[0m")
    time.sleep(2)

    url = "https://whatsapp.com/channel/0029VbBLBZ80lwgrRDEnyV0v"

    if "termux" in os.getenv("PREFIX", "").lower():
        os.system(f"termux-open-url '{url}'")
    elif platform.system() == "Linux":
        os.system(f"xdg-open '{url}'")
    elif platform.system() == "Windows":
        os.system(f"start {url}")
    elif platform.system() == "Darwin":
        os.system(f"open {url}")
    else:
        import webbrowser
        webbrowser.open(url)

def banner_keluar():
    bersihkan_layar()
    print(f"""{m}
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣶⣦
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢐⣿⣿⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣤⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣦⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣶⣾⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⠀⠀⠀⣞⠀⣠⣴⣦⣄⡀⠀⠩⣾⣿⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣶⣿⡿⠟⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⣠⣿⡇⢸⣿⡏⠹⠻⡅⠀⠀⠹⣿⡄⠀
⠀⠀⠀⠀⣀⣠⣴⣾⡿⠿⢻⣿⡏⠁⠀⠀⣾⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣡⣾⠟⠁⠀⠈⠻⣷⣦⡈⠀⠀⠀⠀⠙⠆⠀
⣠⣤⣶⣿⠿⠛⠋⠁⠀⠀⢸⣿⡇⠀⠀⠀⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⣠⣿⣦⠀⣿⣿⣿⣯⣶⣄⠘⣶⣀⣠⣽⣿⠶⠀⠀⢀⣄⡀⠀
⠈⠋⠉⠀⠀⠀⠀⠀⠀⠀⣾⣿⠀⠀⠀⠀⣿⣿⣴⣦⡀⠀⢀⣴⣿⢿⣿⡗⠀⣰⣿⣿⣿⣿⠀⢻⣿⠃⠉⠉⢯⠀⠈⠛⠛⠉⠀⠀⠀⠀⠘⠻⠃⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⢸⣿⣿⡿⣿⡇⠀⣸⣿⢁⣾⡿⣷⠆⣿⡿⠋⠘⠻⢿⡀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⡟⠀⠀⠀⢸⣿⡿⠁⢿⣿⣀⠘⠿⠿⠋⠀⠀⠀⠟⠁⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠉⠁⠀⠀⠉⠛⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⠠⠶⠿⠟⠛⠛⠻⠿⢷⣶⣤⣀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣿⠿⠛⠋⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⢟⠁⠀⣀⣀⠀⠀⠀⠀⣠⣤⣄⠀⠀⠀⠀⠙⣿⣆⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⢰⣿⣿⣷⠀⠀⡿⠿⠿⢿⠀⠀⠀⠀⠀⢸⣿⡆
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⡏⠀⠀⠀⠈⠀⠀⠀⠁⠀⠀⠀⠀⢀⣄⠀⠀⠀⠀⢀⣿⡏
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠃⠀⠀⠀⠀⣶⣆⠀⠀⠀⠀⠀⠀⣼⣿⠀⠀⠀⠀⣼⣿⠃
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡀⠀⠀⠀⠀⠹⣿⣦⡀⠀⠀⣀⣴⣿⠇⠀⠀⠀⣼⣿⠏⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣇⠀⠀⠀⠀⠀⠘⠿⣿⣿⣿⣿⠿⠃⠀⠀⣠⣾⣿⠟⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣼⣿⠟⠃⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣶⣤⣀⣀⣀⣀⣀⣤⣴⣾⣿⠟⠋⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠟⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
""")

def selesai():
    time.sleep(3)
    os.system("clear")
    os.system("login")

def menu_utama():
    while True:
        bersihkan_layar()
        print(f"""{m}
{p}⠀⠀⠀⠀⠀⠀⠀⢀⠆⠀⢀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡀⠀⠰⡀⠀⠀⠀⠀⠀⠀⠀
{m}⠀⠀⠀⠀⠀⠀⢠⡏⠀⢀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢷⡀⠀⢹⣄⠀⠀⠀⠀⠀⠀
{p}⠀⠀⠀⠀⠀⣰⡟⠀⠀⣼⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣧⠀⠀⢻⣆⠀⠀⠀⠀⠀
{m}⠀⠀⠀⠀⢠⣿⠁⠀⣸⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣇⠀⠈⣿⡆⠀⠀⠀⠀
{p}⠀⠀⠀⠀⣾⡇⠀⢀⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡀⠀⢸⣿⠀⠀⠀⠀
{m}⠀⠀⠀⢸⣿⠀⠀⣸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣇⠀⠀⣿⡇⠀⠀⠀
{p}⠀⠀⠀⣿⣿⠀⠀⣿⣿⣧⣤⣤⣤⣤⣤⣤⡀⠀⣀⠀⠀⣀⠀⢀⣤⣤⣤⣤⣤⣤⣼⣿⣿⠀⠀⣿⣿⠀⠀⠀
{m}⠀⠀⢸⣿⡏⠀⠀⠀⠙⢉⣉⣩⣴⣶⣤⣙⣿⣶⣯⣦⣴⣼⣷⣿⣋⣤⣶⣦⣍⣉⡉⠋⠀⠀⠀⢸⣿⡇⠀⠀
{p}⠀⠀⢿⣿⣷⣤⣶⣶⠿⠿⠛⠋⣉⡉⠙⢛⣿⣿⣿⣿⣿⣿⣿⣿⡛⠛⢉⣉⠙⠛⠿⠿⣶⣶⣤⣾⣿⡿⠀⠀
{m}⠀⠀⠀⠙⠻⠋⠉⠀⠀⠀⣠⣾⡿⠟⠛⣻⣿⣿⣿⣿⣿⣿⣿⣿⣟⠛⠻⢿⣷⣄⠀⠀⠀⠉⠙⠟⠋⠀⠀⠀
{p}⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⠿⠋⢀⣠⣾⠟⢫⣿⣿⣿⣿⣿⣿⡍⠻⣷⣄⡀⠙⠿⣷⣤⡀⠀⠀⠀⠀⠀⠀⠀
{m}⠀⠀⠀⠀⠀⣠⣴⡿⠛⠁⠀⢸⣿⣿⠋⠀⢸⣿⣿⣿⣿⣿⣿⡗⠀⠙⣿⣿⡇⠀⠈⠛⢿⣦⣄⠀⠀⠀⠀⠀
{p}⢀⠀⣀⣴⣾⠟⠋⠀⠀⠀⠀⢸⣿⣿⠀⠀⢸⣿⣿⣿⣿⣿⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠙⠻⣷⣦⣀⠀⣀
{m}⢸⣿⣿⠋⠁⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠈⣿⣿⣿⣿⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠈⠙⣿⣿⡟
{p}⢸⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⢹⣿⣿⣿⣿⡏⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡇
{m}⢸⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⢿⣿⣿⡿⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡇
{p}⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠈⠿⠿⠁⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀
{m}⠀⢻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⢀⣿⡟⠀
{p}⠀⠘⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠃⠀
{m}⠀⠀⠸⣷⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⣾⠏⠀⠀
{p}⠀⠀⠀⢻⡆⠀⠀⠀⠀⠀⠀⠀⠸⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⠇⠀⠀⠀⠀⠀⠀⠀⢰⡟⠀⠀⠀
{m}⠀⠀⠀⠀⢷⠀⠀⠀⠀⠀⠀⠀⠀⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡿⠀⠀⠀⠀⠀⠀⠀⠀⡾⠀⠀⠀⠀
{p}⠀⠀⠀⠀⠈⢧⠀⠀⠀⠀⠀⠀⠀⠸⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠇⠀⠀⠀⠀⠀⠀⠀⡸⠁⠀⠀⠀⠀
{m}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡆⠀⠀⠀⠀⠀⠀⠀⠀⢰⡟⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀
{p}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢳⠀⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
{m}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠣⠀⠀⠀⠀⠀⠀⠜⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

{m}╭───────────────{p}>>{m}Credits{p}<<{m}───────────────╮
{m}│ {p}Author {m}: {p}Byexe                          {m}│
{m}│ {p}Github {m}: {p}https://github.com/DaemonTechX {m}│
╰─────────────────────────────────────────╯
{m}╭──────────────{p}>>{m}Menu Main{p}<<{m}──────────────╮
{m}│ {p}01{m}. {p}Cek Keamanan Password Email         {m}│
{m}│ {p}02{m}. {p}Generat Password Email Kuat         {m}│
{m}│ {p}03{m}. {p}Masuk Saluran WhatsApp Byexe        {m}│
{m}│ {p}04{m}. {p}Keluar Menu                         {m}│
╰──╭──────────────────────────────────────╯""")
        
        pilihan = input(f"   ╰─›{p} ")
        
        if pilihan == '1':
            menu_cek_password()
        elif pilihan == '2':
            menu_buat_password()
        elif pilihan == '3':
            saluran_menu3()
        elif pilihan == '4':
            bersihkan_layar()
            banner_keluar()
            saluran_menu4()
            selesai()
            break
        else:
            print(f"\n{m}[!] Pilihan tidak valid!{r}")
            input(f"\n{m}Enter Untuk Kembali{r}")

if __name__ == "__main__":
    menu_utama()

