#Sabtu - 1 - November - 2025
#Decode By Andrax Dev
#si kontol andrax malesan tai makanya dia pake auto njir :v
#Tools Decode By Andrax C2

import requests
import os
import time

a = "\033[1;30m"
m = "\033[1;31m"
h = "\033[1;32m"
k = "\033[1;33m"
c = "\033[1;36m"
p = "\033[1;37m"
r = "\033[0m"

def banner_youtube():
    os.system("clear")
    print(f"""
{a}⠀⠀⢀⣀⣠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣄⣀⡀⠀⠀
{a}⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀
{a}⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀
{a}⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆
{a}⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠈⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
{a}⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⢈⣹⣿⣿⣿⣿⣿⣿⣿⡇{m}╔═╦╗╔╦╗╔═╦═╦╦╦╦╗╔═╗
{a}⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⢀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇{m}║╚╣║║║╚╣╚╣╔╣╔╣║╚╣═╣
{a}⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇{p}╠╗║╚╝║║╠╗║╚╣║║║║║═╣
{a}⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀{p}╚═╩══╩═╩═╩═╩╝╚╩═╩═╝
{a}⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀
{a}⠀⠀⠈⠉⠙⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠋⠉⠁
 {a}[ {m}> {p}Please Support My YouTube {m}< {a}]
""")

def banner_whatsapp():
    os.system("clear")
    print(f"""{h}
⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣤⣶⣶⣶⣶⣤⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡀⠀⠀⠀⠀
⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⡿⠟⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀
⠀⣾⣿⣿⣿⣿⡟⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀
⢠⣿⣿⣿⣿⣿⣧⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄
⢸⣿⣿⣿⣿⣿⣿⣦⠀⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
⠘⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠈⠻⢿⣿⠟⠉⠛⠿⣿⣿⣿⣿⣿⣿⠃
⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⡀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⡿⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣤⣤⣴⣾⣿⣿⣿⣿⡿⠁⠀
⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀⠀⠀⠀
⠠⠛⠛⠛⠉⠁⠀⠈⠙⠛⠛⠿⠿⠿⠿⠛⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀

{a}[ {m}> {p}Follow My WhatsApp Channel To Get Latest Tools Information {m}<{a} ]
""")

def buka_youtube():
    banner_youtube()
    url = "https://youtube.com/@byexeofficial"
    time.sleep(3)

    if "termux" in os.getenv("PREFIX", "").lower():
        os.system(f"termux-open-url '{url}'")
    elif platform.system() == "Linux":
        os.system(f"xdg-open '{url}'")
    elif platform.system() == "Windows":
        os.system(f"start {url}")
    elif platform.system() == "Darwin":
        os.system(f"open {url}")
    else:
        import webbrowser
        webbrowser.open(url)

def buka_saluran():
    banner_whatsapp()
    url = "https://whatsapp.com/channel/0029VbBLBZ80lwgrRDEnyV0v"
    time.sleep(3)

    if "termux" in os.getenv("PREFIX", "").lower():
        os.system(f"termux-open-url '{url}'")
    elif platform.system() == "Linux":
        os.system(f"xdg-open '{url}'")
    elif platform.system() == "Windows":
        os.system(f"start {url}")
    elif platform.system() == "Darwin":
        os.system(f"open {url}")
    else:
        import webbrowser
        webbrowser.open(url)

class AIGroqChat:
    def __init__(self):
        self.api_url = "https://api.groq.com/openai/v1/chat/completions"
        self.api_key = "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"
        self.conversation_history = []
    
    def send_message(self, user_input):
        try:
            self.conversation_history.append({
                "role": "user",
                "content": user_input
            })
            
            payload = {
                "model": "llama-3.3-70b-versatile",
                "messages": self.conversation_history,
                "temperature": 0.7,
                "max_tokens": 2048
            }
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
            print()
            response = requests.post(self.api_url, json=payload, headers=headers, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                ai_response = data['choices'][0]['message']['content']
                
                self.conversation_history.append({
                    "role": "assistant",
                    "content": ai_response
                })
                
                return ai_response
            else:
                return f"{m}Error: Status code {response.status_code} - {response.text}{r}"
                
        except requests.exceptions.Timeout:
            return f"{m}Timeout: API tidak merespons{r}"
        except requests.exceptions.RequestException as e:
            return f"{m}Error koneksi: {str(e)}{r}"
        except Exception as e:
            return f"{m}Error: {str(e)}{r}"

def ai_main():
    os.system("clear")
    print(f"""
  {m}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀{m}⣤⣤⡶⠶⠾⠟⠛⠛⠛⠛⠛⠛⠛⡛⠛⠛⠻⠷⠶⢶⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
  {m}⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⠶⠛⢋{a}⣉⣥⡴⠂⠀⠀⠀⠀⠀⣾⣄⣀⣀⣰⡇⠀⠀⠀⠀⠀⠰⣤⣤⣉{m}⡙⠛⠶⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀
  {m}⠀⠀⠀⠀⢀⣤⡾⠛{a}⣉⣤⣶⣿⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣶⣤⣉{m}⠛⢷⣤⡀⠀⠀⠀⠀
  {m}⠀⠀⢀⣴⠟{a}⣁⣴⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣷⣦{m}⡈⠻⣦⡀⠀⠀
  {m}⠀⣰⡟⢁{a}⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣄⣀⣀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣦⣀⣀⣠⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦{m}⡈⢿⣆⠀
  {m}⢠⡿⢁{a}⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡈{m}⢿⡄
  {m}⣾⡇{a}⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇{m}⢸⣧
  {m}⢿⡇{a}⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇{m}⢸⣏
  {m}⠘⣿⡀{a}⢿⣿⣿⣿⣿⣿⣿⣿⠋⠉⠉⠉⠻⢿⣿⣿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢿⣿⣿⡿⠛⠉⠉⠉⠹⣿⣿⣿⣿⣿⣿⣿⠟{m}⢠⣿⠁
  {m}⠀⠈⢿⣆{a}⠙⢿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠙⠃⠀⠀⠈⢿⣿⣿⣿⣿⡟⠁⠀⠀⠹⠁⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⡿⠋{m}⣠⡿⠁⠀
  {m}⠀⠀⠀⠙⢷⣦{a}⡙⠻⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⡿⠟⢉{m}⣤⡾⠋⠀⠀⠀
  {m}⠀⠀⠀⠀⠈⠙⠷⣦⣍{a}⡛⠻⢿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⡿⠟⢋{m}⣡⣴⠾⠋⠁⠀⠀⠀⠀
  {m}⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠷⢶⣤⣅⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣨{m}⣤⡶⠾⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀
  {m}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠛⠷⠶⠶⠶⣶⣤⣤⣤⣤⣤⣴⣶⠶⠶⠶⠟⠛⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

                  {a}[ {m}> {p}AI CHAT {m}< {a}]
   {h}• {p}Ketik {m}EXIT {p}Untuk Kembali Ke Menu NightBatTools {h}•
""")
    
    chat = AIGroqChat()
    
    while True:
        try:
            user_input = input(f"{a}[ {m}> {p}YOU {m}< {a}] {m}:: {p}").strip()
            print(r, end='')
            
            if not user_input:
                continue
            
            if user_input.lower() in ['/exit', 'exit', 'quit']:
                break
            
            response = chat.send_message(user_input)
            print(f"\n{a}[ {m}> {p}AI {m}<{a} ] {m}:: {p}{response}{r}\n")
            
        except KeyboardInterrupt:
            input(f"\n{a}[{m}!{a}]{p} Kembali Ke Menu NightBatTools {a}| \033[101m\033[1;32m ENTER  \033[0m\n")
            break
        except Exception as e:
            print(f"\n{a}[{m}✗{a}]{p} Error{m}: {a}{e}{r}\n")

if __name__ == "__main__":
    buka_youtube()
    input(f"\n{a}[{m}!{a}]{p} Lanjut Untuk Berinteraksi Dengan AI {a}| \033[101m\033[1;32m ENTER \033[0m\n")
    buka_saluran()
    input(f"\n{a}[{m}!{a}]{p} Lanjut Untuk Berinteraksi Dengan AI {a}| \033[101m\033[1;32m ENTER \033[0m\n")
    ai_main()

