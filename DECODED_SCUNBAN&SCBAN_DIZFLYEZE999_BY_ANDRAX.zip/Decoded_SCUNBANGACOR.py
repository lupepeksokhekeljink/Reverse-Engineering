#!/usr/bin/env python3
#By Andrax Decode
import os
import sys
import time
import platform
import re
import random
import string
import subprocess
import hashlib
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, BarColumn, TextColumn, SpinnerColumn
from rich import box

console = Console()

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def loading_animasi(text, duration=2):
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold yellow]{task.description}"),
        BarColumn(),
        transient=True,
    ) as progress:
        progress.add_task(description=text, total=None)
        time.sleep(duration)

def deteksi_perangkat():
    try:
        system = platform.system()
        release = platform.release()
        machine = platform.machine()

        if system == "Linux":
            try:
                props = subprocess.check_output(["getprop"], text=True, stderr=subprocess.DEVNULL)
                model = re.search(r'\[ro.product.model\]: \[(.*?)\]', props)
                brand = re.search(r'\[ro.product.brand\]: \[(.*?)\]', props)
                android_ver = re.search(r'\[ro.build.version.release\]: \[(.*?)\]', props)

                if model and android_ver:
                    brand_name = brand.group(1) if brand else "UnknownBrand"
                    return f"{brand_name} Android {android_ver.group(1)}"
            except Exception:
                pass
            return f"Linux {release} ({machine})"

        elif system == "Windows":
            try:
                import winreg
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion") as key:
                    product_name = winreg.QueryValueEx(key, "ProductName")[0]
                    build_number = winreg.QueryValueEx(key, "CurrentBuildNumber")[0]
                    return f"{product_name} Build {build_number} {machine}"
            except Exception:
                win_ver = sys.getwindowsversion()
                major, minor, build = win_ver.major, win_ver.minor, win_ver.build
                if major == 10 and build >= 22000:
                    return f"Windows 11 Build {build} {machine}"
                elif major == 10:
                    return f"Windows 10 Build {build} {machine}"
                elif major == 6 and minor == 3:
                    return f"Windows 8.1 Build {build} {machine}"
                elif major == 6 and minor == 2:
                    return f"Windows 8 Build {build} {machine}"
                elif major == 6 and minor == 1:
                    return f"Windows 7 Build {build} {machine}"
                else:
                    return f"Windows {major}.{minor} Build {build} {machine}"

        elif system == "Darwin":
            try:
                mac_ver = platform.mac_ver()[0]
                darwin_major = release.split('.')[0]
                mac_versions = {
                    "22": "macOS Ventura", "21": "macOS Monterey", "20": "macOS Big Sur",
                    "19": "macOS Catalina", "18": "macOS Mojave", "17": "macOS High Sierra",
                    "16": "macOS Sierra", "15": "OS X El Capitan", "14": "OS X Yosemite",
                    "13": "OS X Mavericks", "12": "OS X Mountain Lion", "11": "OS X Lion"
                }
                version_name = mac_versions.get(darwin_major, f"macOS {mac_ver}")
                return f"{version_name} {machine} {processor}"
            except Exception:
                return f"macOS {release} {machine}"

        else:
            return f"{system} {release} {machine} {processor}"

    except Exception as e:
        return f"Perangkat Tidak Dikenal - {str(e)}"

def buka_link(url):
    try:
        system = platform.system()
        if system == "Windows":
            os.system(f'start "" "{url}"')
        elif system == "Darwin":
            os.system(f'open "{url}"')
        else:
            os.system(f'xdg-open "{url}"')
    except Exception as e:
        console.print(f"[bold red]Gagal membuka link: {str(e)}[/]")

def normalisasi_nomor(nomor):
    nomor_bersih = re.sub(r'\D', '', nomor)
    return nomor_bersih

def validasi_nomor(nomor_bersih):
    if not nomor_bersih:
        return False, "Anda Harus Mengetikan Angka Dengan Benar"
    
    if len(nomor_bersih) < 8:
        return False, "Nomor terlalu pendek! Minimal 8 digit."
    
    if len(nomor_bersih) > 15:
        return False, "Nomor terlalu panjang! Maksimal 15 digit."
    
    if not nomor_bersih.isdigit():
        return False, "Nomor harus berisi angka doang!"
    
    return True, "Nomor valid"

def deteksi_kode_negara(nomor):
    data_negara = {
        '1': {'name': 'USA/Canada', 'min': 10, 'max': 11},
        '62': {'name': 'Indonesia', 'min': 9, 'max': 13},
        '60': {'name': 'Malaysia', 'min': 9, 'max': 11},
        '63': {'name': 'Philippines', 'min': 10, 'max': 11},
        '65': {'name': 'Singapore', 'min': 8, 'max': 9},
        '66': {'name': 'Thailand', 'min': 9, 'max': 10},
        '84': {'name': 'Vietnam', 'min': 9, 'max': 11},
        '86': {'name': 'China', 'min': 11, 'max': 12},
        '81': {'name': 'Japan', 'min': 10, 'max': 11},
        '82': {'name': 'South Korea', 'min': 9, 'max': 11},
        '91': {'name': 'India', 'min': 10, 'max': 12},
        '44': {'name': 'UK', 'min': 10, 'max': 11},
        '49': {'name': 'Germany', 'min': 10, 'max': 12},
        '33': {'name': 'France', 'min': 9, 'max': 10},
        '39': {'name': 'Italy', 'min': 10, 'max': 11},
        '34': {'name': 'Spain', 'min': 9, 'max': 10},
        '7': {'name': 'Russia', 'min': 10, 'max': 11},
        '55': {'name': 'Brazil', 'min': 10, 'max': 12},
        '52': {'name': 'Mexico', 'min': 10, 'max': 11},
        '61': {'name': 'Australia', 'min': 9, 'max': 10},
        '64': {'name': 'New Zealand', 'min': 8, 'max': 10},
        '27': {'name': 'South Africa', 'min': 9, 'max': 10},
        '20': {'name': 'Egypt', 'min': 10, 'max': 11},
        '234': {'name': 'Nigeria', 'min': 10, 'max': 11},
        '966': {'name': 'Saudi Arabia', 'min': 9, 'max': 10},
        '971': {'name': 'United Arab Emirates', 'min': 9, 'max': 10},
    }
    
    for kode in sorted(data_negara.keys(), key=len, reverse=True):
        if nomor.startswith(kode):
            sisa_nomor = nomor[len(kode):]
            info_negara = data_negara[kode]
            if len(sisa_nomor) >= info_negara['min'] and len(sisa_nomor) <= info_negara['max']:
                return kode, info_negara['name'], sisa_nomor
    
    return '62', 'Indonesia', nomor

def buat_teks_unban(nomor):
    nomor_bersih = normalisasi_nomor(nomor)
    kode_negara, nama_negara, nomor_lokal = deteksi_kode_negara(nomor_bersih)
    
    nomor_lengkap = f"+{kode_negara}{nomor_lokal}"
    
    TeksUnban = f"""[bold white]Dear WhatsApp Team,
 
I am writing to you with a sincere plea, as the blocking of my WhatsApp account is not merely a digital inconvenience, but a critical disruption to my primary means of communication with family, friends, colleagues, and the community that forms an integral part of my daily life. This block has had a significant impact, not only on my communication but also on my productivity, professional responsibilities, and the social bonds I deeply cherish.
 
I understand that every action taken by WhatsApp is based on security standards and policy compliance. I also recognize that violations, whether intentional or unintentional, can have consequences. However, I want to emphasize that all my activities while using WhatsApp have always been in good faith. I have never intentionally engaged in spam, abuse, fraud, or any other violations that contravene the terms of service.
 
Throughout my time using WhatsApp, I have relied on this platform not only as a regular communication tool but also as a medium for disseminating important information, reminding myself of responsibilities, and maintaining emotional connections with loved ones. Losing access to this has caused a genuine sense of loss, even uncertainty that affects my daily life and work.
 
I implore the WhatsApp team to reconsider this blocking decision, with the hope of being given a second chance. I am willing to take any necessary corrective steps, including additional identity verification, relearning usage policies, or other preventative measures that the team deems relevant, to ensure that my account usage fully complies with the established standards going forward.
 
I believe that every platform, including WhatsApp, stands not only on algorithms and automated systems but also on the values of humanity, opportunity, and trust. With humility, I request that this blocking decision be reviewed, and my account be permanently restored so that I can continue my communication, responsibilities, and social roles without hindrance.
 
Thank you for the attention, time, and understanding of the WhatsApp team. I look forward to a response that provides clarity, and I am committed to complying with every policy to create a safe, comfortable, and mutually respectful communication ecosystem.
 
If the Team Needs an Address To Contact, Please Contact Me At the Following Data:
Personal Name: Diz Flyze Official
Blocked Number: {nomor_lengkap}
Request: Unblocking of Blocked WhatsApp Account[/bold white]"""
    return TeksUnban

def tampilkan_header():
    WAKTU = datetime.now().strftime("%H:%M:%S")
    TANGGAL = datetime.now().strftime("%d/%m/%Y")
    PERANGKAT = deteksi_perangkat()
    
    LOGO = """[bold green]
⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣤⣶⣶⣶⣶⣤⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡀⠀⠀⠀⠀
⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⡿⠟⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀
⠀⣾⣿⣿⣿⣿⡟⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀
⢠⣿⣿⣿⣿⣿⣧⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄ [/][bold yellow]WhatsApp Business[/][bold green]
⢸⣿⣿⣿⣿⣿⣿⣦⠀⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇ [/][bold yellow]WhatsApp Original[/][bold green]
⠘⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠈⠻⢿⣿⠟⠉⠛⠿⣿⣿⣿⣿⣿⣿⠃ [/][bold yellow]WhatsApp Beta New[/][bold green]
⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⡀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⡿⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣤⣤⣴⣾⣿⣿⣿⣿⡿⠁⠀
⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀⠀⠀⠀
⠠⠛⠛⠛⠉⠁⠀⠈⠙⠛⠛⠿⠿⠿⠿⠛⠛⠋⠁
[/]"""
    
    INFO = f"[bold white]PEMBUAT SC   : Diz Flyze Official[/]\n[bold white]DEVICE ANDA  : {PERANGKAT}[/]\n"
    INFO += f"[bold white]WAKTU RUNING : {WAKTU}[/]\n[bold white]TANGGAL RUN  : {TANGGAL}[/]\n"
    INFO += f"[bold white]VERSI UPDATE : v2.25.26.74[/]\n[bold white]SUPORT UNBAN : 26 Negara[/]\n"
    
    panel_content = f"{LOGO}\n{INFO}"
    
    return Panel(
        panel_content,
        box=box.DOUBLE,
        padding=(0, 1),
        title="[bold white]SC UNBAN WHATSAPP PREMIUM[/]",
        title_align="center",
        border_style="bold green"
    )

def verifikasi_kunci(input_key):
    kunci_benar = "deee9c54459f164ae71d9aba5a4cf7499efcf87c2c725f82780f68552b1104c7"
    hash_input = hashlib.sha256(input_key.encode()).hexdigest()
    return hash_input == kunci_benar

def tampilkan_tutorial_dan_method(nomor):
    clear()
    console.print(tampilkan_header())
    
    kode_negara, nama_negara, nomor_lokal = deteksi_kode_negara(normalisasi_nomor(nomor))
    nomor_lengkap = f"+{kode_negara}{nomor_lokal}"
    
    teks_unban = buat_teks_unban(nomor)
    console.print(
        Panel(
            f"""
[bold yellow]Hallo Pengguna Premium![/]

[bold white]Terimakasih atas partisipasinya menggunakan script saya![/]

[bold yellow]Kita masuk ke tahap 1:[/]
[bold white]▶ Buka WhatsApp
▶ Bantuan
▶ Hubungi Kami
▶ Tempel Method![/]

[bold yellow]Kita masuk ke tahap 2:[/]
[bold white]▶ Download WA Ori/Business Belum Terdaftar!
▶ Pojok kanan ada titik 3
▶ Click Bantuan
▶ Kirimkan Method

[bold yellow]Kita masuk ke tahap 3:
[bold white]▶ Web https://www.whatsapp.com/contact
▶ Ganti Ke nomer kamu yang di banned
▶ Email random @gmail.com contoh abc@gmail.com
▶ Tempel methodnya kesitu di colom paling bawah
▶ Click Lanjutkan 2x Sampai Bacaan Terimakasih!

[bold yellow]Sekian Tutorial Unban Dari Saya Semoga Paham[/]
""",
            title="[bold cyan]TUTORIAL UNBAN[/]",
            style="bold yellow"
        )
    )
    
    console.print(
        Panel("Salin Semua Method Unban Di Bawah Ini",title="[bold white]TEKS METHOD UNBAN[/]",
            style="bold green"
        )
    )
    console.print(f"[bold white]{teks_unban}[/]\n")
    
    console.print(
        Panel(
            f"[bold green]📞 Telegram [bold white]: [bold yellow]https://t.me/dizflyzeofc[/]\n"
            f"[bold green]🌐 YouTube [bold white] : [bold yellow]youtube.com/@dizflyze999[/]",
            title="[bold white]JIKA BINGUNG TANYAKAN KE[/]",
            style="bold white"
        )
    )
    
    buka_link("https://youtube.com/@dizflyze999?si=kxC5991hujkPGO_J")

def main():
    try:
        loading_animasi("Tunggu Memuat Bahan!", 32)
        clear()
        
        console.print(tampilkan_header())
        console.print(
            Panel(
                f"""[bold cyan]🍁 Ketik Nomer Yang Mau DI Unbanned!\n[bold white]❓ Contoh : +1XXX / +62XXX / +60XXX[/]""", 
                style="bold white"
            )
        )
        
        nomor_input = console.input("[bold white]┕⚞ [/]")
        nomor_bersih = normalisasi_nomor(nomor_input)
        is_valid, pesan_error = validasi_nomor(nomor_bersih)
        
        if not is_valid:
            console.print(Panel(f"[bold red]❌ {pesan_error}[/]"), style="bold white")
            time.sleep(2)
            return
        
        kode_negara, nama_negara, nomor_lokal = deteksi_kode_negara(nomor_bersih)
        nomor_lengkap = f"+{kode_negara}{nomor_lokal}"
        
        loading_animasi(f" {nama_negara}", 2)
        clear()
        PERANGKAT = deteksi_perangkat()
        console.print(tampilkan_header())
        console.print(
            Panel(
                f"""[bold white]Deteksi Negara : {nama_negara}
Nomor WhatsApp : {nomor_lengkap}
Panjang Nomor  : {len(nomor_bersih)} Digit
Status Script  : Siap Di Unban""",
                title="[bold yellow]INFORMATION[/]",
                style="bold white"
            )
        )
        console.print(
            Panel(
                f"""[bold yellow]🔑 Masukan Kunci Akses Terlebih Dahulu!\n[bold white]Belum Punya Kunci?\nUpgrade Premium Ke t.me/dizflyzeofc""",
                title="[bold cyan]KUNCI MASUK[/]",
                style="bold white"
            )
        )
        
        kunci = console.input("[bold white]┕⚞ [/]")
        
        if not verifikasi_kunci(kunci):
            console.print(
                Panel(
                    f"""[bold white]Kunci Akses Salah Total!
                    
Dapatkan Kunci Dengan Berlangganan Ke https://t.me/dizflyzeofc di Telegram
          
Fitur Premium?
• Support unban wa global 200+ negara
• Tingkat keberhasilan (99.9%)
• Support developer langsung
• Update seumur hidup
• Support multi-bahasa[/]""", 
                    title="[bold yellow]USER NOT PREMIUM[/]",
                    style="bold red"
                    
                )
            )
            buka_link("https://t.me/dizflyzeofc")
            return
        
        loading_animasi(" Sedang Proses Bypass", 33)
        clear()
        console.print(tampilkan_header())
        
        console.print(
            Panel(
                f"""[bold green]Selamat Datang Pengguna Premium!

[bold white]Negara : {nama_negara}
Nomor  : {nomor_lengkap}
Device : {PERANGKAT}

[bold cyan]Tunggu Sedang Dalam Mempersiapkan Data Dan Bypass Lebih Mendalam Ke WhatsApp[/]""",
                title="[bold yellow]WELCOME USER PREMIUM[/]",
                style="bold green"
            )
        )
        
        time.sleep(2)
        loading_animasi("BYPASS AI SUPPORT", 128)
        loading_animasi("INJECTION PARAMETER", 109)
        loading_animasi("MENGANALISIS DATA", 55)
        loading_animasi("PROSES PERSIAPAN", 180)
        loading_animasi("MENGECEK DATABASE", 102)
        loading_animasi("MENGAKTIFKAN BOT", 120)
        loading_animasi("CEK DEVICE SUPPORT", 200)
        
        console.print(
            Panel(
                f"""[bold yellow]Dear User Premium :[/]
[bold white]Script gagal membypass karena perangkat anda tidak sepenuhnya atau menolak untuk mendukung script unbanned otomatis!

[bold yellow]Saran Kami Adalah :[/]
[bold white]Silahkan ikuti tutorial di bawah setelah mengetikan Y dan anda harus menunggu 6 jam kedepan maka banned akan otomatis terbuka![/]""",
                title="[bold yellow]DEVICE NOT SUPPORTED[/]",
                style="bold white"
            )
        )
        
        console.print(
            Panel(
                f"""[bold yellow]❓ Lanjut Ke Method Manual? (Y/N)[/]""", 
                style="bold white"
            )
        )
        
        pilihan = console.input("[bold white]┕⚞ [/]").strip().lower()
        
        if pilihan in ['y', 'yes', 'ya', 'y']:
            tampilkan_tutorial_dan_method(nomor_bersih)
        else:
            console.print(
                Panel(
                    f"""[bold cyan]Terimakasih Sudah Menggunakan Script Ini Diz Flyze Meminta Maaf Jika Device Anda Tidak Di Dukung Penuh Untuk Script Ini[/]""", 
                    style="bold red",
                    title="[bold yellow]I AM SORRY[/]"
                )
            )
            
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Exiting[/]")
    except Exception as e:
        console.print(f"[bold red]Terjadi Kesalahan : {str(e)}[/]")
        console.print("[bold yellow]Harap Hubungi Developer Agar Segera Di Perbaiki : https://t.me/dizflyzeofc[/]")

if __name__ == "__main__":
    main()
