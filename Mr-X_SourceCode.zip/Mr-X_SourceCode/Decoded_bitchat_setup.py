#!/usr/bin/env python3
# Setup otomatis Bitchat v1.0 untuk Termux (kompatibel)
# Create by Mr.X

import os
import sys
import subprocess

# ======= UTILITY =======
def run(cmd):
    try:
        result = subprocess.run(cmd, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return result.stdout.decode().strip()
    except subprocess.CalledProcessError:
        return None

def check_command(cmd):
    return run(f"command -v {cmd}") is not None

# ======= CHECK PYTHON =======
if not check_command("python") and not check_command("python3"):
    print("❌ Python belum terinstall. Install dulu: pkg install python")
    sys.exit(1)
else:
    print("✅ Python ditemukan")

# ======= CHECK PIP =======
if not check_command("pip"):
    print("⚠️ pip belum ditemukan. Mencoba install pip...")
    os.system("python -m ensurepip")
else:
    print("✅ pip tersedia")

# ======= CHECK TERMUX-API =======
if not check_command("termux-toast"):
    print("⚠️ termux-api belum terinstall. Install dulu: pkg install termux-api")
else:
    print("✅ termux-api tersedia")

# ======= CREATE requirements.txt =======
reqs = """colorama==0.4.6
pyfiglet>=0.8.post1
"""

if not os.path.exists("requirements.txt"):
    with open("requirements.txt", "w") as f:
        f.write(reqs)
    print("✅ requirements.txt dibuat")
else:
    print("📄 requirements.txt sudah ada, dilewati")

# ======= INSTALL DEPENDENCIES =======
print("🚀 Menginstall dependency dari requirements.txt...")
os.system("pip install -r requirements.txt")

print("\n🎉 Setup selesai! Kamu siap menjalankan Bitchat v1.0")
print("Jalankan: python bitchat_v1.py")
