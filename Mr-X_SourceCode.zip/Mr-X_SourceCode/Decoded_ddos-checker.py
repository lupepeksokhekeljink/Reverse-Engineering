import requests
import socket
import time
import os
import concurrent.futures
import ssl
import json
import urllib.request
import threading
from prettytable import PrettyTable
from pyfiglet import figlet_format
import dns.resolver
from urllib.parse import urljoin
from bs4 import BeautifulSoup

def banner():
    os.system("clear" if os.name == "posix" else "cls")
    print(figlet_format("ddos-checker"))
    print("Created by Mr.X - Website DDoS Analyzer\n")

def get_ip(domain):
    try:
        return socket.gethostbyname(domain)
    except:
        return None

def geoip_lookup(ip):
    try:
        with urllib.request.urlopen(f"https://ipinfo.io/{ip}/json") as response:
            data = json.load(response)
            return data.get("city", "Unknown") + ", " + data.get("region", "Unknown") + ", " + data.get("country", "Unknown")
    except:
        return "Unknown"

def check_dns_ttl(domain):
    try:
        answer = dns.resolver.resolve(domain, 'A')
        for rdata in answer.response.answer:
            return rdata.ttl
    except:
        return None

def check_cdn(headers):
    cdn_indicators = ["cloudflare", "akamai", "sucuri", "fastly"]
    for key, val in headers.items():
        val = val.lower()
        for cdn in cdn_indicators:
            if cdn in val:
                return cdn.capitalize()
    return "None Detected"

def detect_firewall(headers):
    firewall_keywords = {
        "Cloudflare": ["cf-ray", "server: cloudflare"],
        "Sucuri": ["x-sucuri-id", "x-sucuri-cache"],
        "AWS WAF": ["x-amzn-requestid", "x-amz-apigw-id"],
        "Imperva/Incapsula": ["x-cdn", "x-iinfo"],
        "DDoS-Guard": ["server: ddos-guard"]
    }

    header_combined = "\n".join([f"{k.lower()}: {v.lower()}" for k, v in headers.items()])
    detected = []

    for fw_name, indicators in firewall_keywords.items():
        if any(indicator in header_combined for indicator in indicators):
            detected.append(fw_name)

    return detected if detected else ["Not Detected"]

def response_time(url):
    try:
        start = time.time()
        res = requests.get(url, timeout=5)
        end = time.time()
        return round(end - start, 3), res
    except:
        return None, None

def stress_test(url, count=50):
    output = ["\n[!] Melakukan stress test ringan ({} permintaan)...".format(count)]
    errors = 0
    times = []

    def send_request():
        nonlocal errors
        try:
            start = time.time()
            r = requests.get(url, timeout=5)
            times.append(time.time() - start)
            return r.status_code
        except:
            errors += 1
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        status_codes = list(executor.map(lambda _: send_request(), range(count)))

    most_common = max(set(status_codes), key=status_codes.count) if status_codes else "N/A"
    avg_response = sum(times)/len(times) if times else "Timeout"

    output.append(f"  - Permintaan berhasil : {count - errors}")
    output.append(f"  - Permintaan gagal    : {errors}")
    output.append(f"  - Status code umum    : {most_common}")
    output.append(f"  - Rata-rata respon    : {round(avg_response, 3)} detik" if isinstance(avg_response, float) else "  - Timeout semua")

    if errors > count * 0.3:
        output.append("  - [!] Server rentan overload. Potensi DDoS tinggi.")
    elif isinstance(avg_response, float) and avg_response > 2:
        output.append("  - [!] Respon lambat saat traffic meningkat.")
    else:
        output.append("  - [OK] Server cukup stabil untuk beban ringan.")

    for line in output:
        print(line)
    return output

def port_scan(ip):
    print("\n[!] Melakukan pemindaian port umum...")
    common_ports = {
        21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
        80: "HTTP", 110: "POP3", 123: "NTP", 143: "IMAP", 161: "SNMP",
        443: "HTTPS", 445: "SMB", 3306: "MySQL", 3389: "RDP", 
        1900: "SSDP", 11211: "Memcached", 19: "Chargen"
    }

    open_ports = []
    for port, name in common_ports.items():
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((ip, port))
        if result == 0:
            open_ports.append((port, name))
        sock.close()

    if open_ports:
        print("[+] Port terbuka terdeteksi:")
        for port, service in open_ports:
            alert = " - Rawan DDoS" if service in ["NTP", "DNS", "Memcached", "SSDP", "Chargen"] else ""
            print(f"  - Port {port} ({service}){alert}")
    else:
        print("[-] Tidak ada port umum yang terbuka terdeteksi.")

    return open_ports

def full_port_scan(ip):
    print("\n[!] Melakukan full port scan (1–65535)... Bisa makan waktu beberapa menit.")
    open_ports = []

    def scan(port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.1)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    open_ports.append(port)
        except:
            pass

    threads = []
    for port in range(1, 65536):
        t = threading.Thread(target=scan, args=(port,))
        threads.append(t)
        t.start()
        if len(threads) >= 500:
            for thread in threads:
                thread.join()
            threads.clear()

    for thread in threads:
        thread.join()

    print(f"[+] Total port terbuka: {len(open_ports)}")
    if open_ports:
        print("    ", ", ".join(map(str, sorted(open_ports))))
    return open_ports

def analyze_resilience(url):
    print("\n[!] Menganalisis daya tahan target berdasarkan konten halaman...")
    try:
        res = requests.get(url, timeout=5)
        base_size = len(res.content)
        total_size = base_size
        soup = BeautifulSoup(res.text, "html.parser")
        static_files = []

        for tag in soup.find_all(["img", "script", "link"]):
            src = tag.get("src") or tag.get("href")
            if src and not src.startswith("data:"):
                full_url = urljoin(url, src)
                static_files.append(full_url)

        for link in static_files:
            try:
                r = requests.head(link, timeout=5, allow_redirects=True)
                size = int(r.headers.get("Content-Length", 0))
                total_size += size
            except:
                continue

        total_kb = round(total_size / 1024, 2)
        print(f"[+] Ukuran total halaman dan resource: ~{total_kb} KB")

        estimated_hits = round((100 * 1024 * 1024) / total_size)
        print(f"[+] Estimasi jumlah request untuk menghabiskan 100MB bandwidth: ~{estimated_hits} kali")

        return total_kb

    except Exception as e:
        print("[-] Gagal menganalisis daya tahan target:", str(e))
        return None

def detect_rate_limiting(url):
    print("\n[!] Mengecek rate-limiting (anti-flood)...")
    status_codes = []

    for _ in range(10):
        try:
            r = requests.get(url, timeout=3)
            status_codes.append(r.status_code)
            time.sleep(0.5)
        except:
            status_codes.append("Timeout")

    if 429 in status_codes or status_codes.count(403) > 2:
        print("[!] Terdeteksi rate-limiting (HTTP 429 atau 403 sering muncul).")
    else:
        print("[OK] Tidak terdeteksi rate-limiting secara jelas.")

def ssl_tls_scan(domain):
    print("\n[!] Memeriksa info sertifikat SSL/TLS...")
    context = ssl.create_default_context()
    try:
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                protocol = ssock.version()
                print(f"[+] TLS Version: {protocol}")
                print(f"[+] Common Name: {cert.get('subject', [['CN', 'Unknown']])[0][0][1]}")
                print(f"[+] Expiry: {cert.get('notAfter')}")
    except Exception as e:
        print(f"[-] Gagal cek SSL/TLS: {e}")

def save_report(data, domain):
    print("\nIngin menyimpan laporan?")
    print("  [1] Ya, format TXT")
    print("  [2] Ya, format HTML")
    print("  [3] Ya, format JSON")
    print("  [4] Tidak")
    pilihan = input("Pilih opsi (1-4): ").strip()

    filename_base = f"ddos_report_{domain.replace('.', '_')}"

    if pilihan == "1":
        with open(f"{filename_base}.txt", "w") as f:
            f.write(data)
        print(f"[+] Laporan disimpan sebagai {filename_base}.txt")
    elif pilihan == "2":
        html_content = f"<html><body><pre>{data}</pre></body></html>"
        with open(f"{filename_base}.html", "w") as f:
            f.write(html_content)
        print(f"[+] Laporan disimpan sebagai {filename_base}.html")
    elif pilihan == "3":
        try:
            json_data = json.loads(data)
        except:
            json_data = {"report": data}
        with open(f"{filename_base}.json", "w") as f:
            json.dump(json_data, f, indent=4)
        print(f"[+] Laporan disimpan sebagai {filename_base}.json")
    else:
        print("[-] Laporan tidak disimpan.")

def analyze(domain, mode="passive"):
    report_lines = []
    ip = get_ip(domain)
    if not ip:
        print("Unable to resolve domain.")
        return

    url = f"http://{domain}"
    resp_time, response = response_time(url)
    ttl = check_dns_ttl(domain)
    cdn = check_cdn(response.headers) if response else "Unknown"
    firewall = detect_firewall(response.headers) if response else ["Unknown"]

    x = PrettyTable()
    x.field_names = ["Parameter", "Result"]
    x.add_row(["IP Address", ip])
    x.add_row(["GeoIP Location", geoip_lookup(ip)])
    x.add_row(["DNS TTL", ttl if ttl else "Unknown"])
    x.add_row(["CDN Used", cdn])
    x.add_row(["Firewall Detected", ", ".join(firewall)])
    x.add_row(["Response Time", f"{resp_time} sec" if resp_time else "Timeout"])
    print(x)
    report_lines.append(x.get_string())

    ssl_tls_scan(domain)
    detect_rate_limiting(url)

    score = 0
    if mode == "aggressive":
        output = stress_test(url)
        report_lines.extend(output)
        ports = port_scan(ip)
        all_open_ports = full_port_scan(ip)
        page_kb = analyze_resilience(url)

        layer4_vuln = any(port for port, service in ports if service in ["NTP", "DNS", "Memcached", "SSDP", "Chargen"])
        layer7_vuln = page_kb and page_kb > 1024

        vuln_score = 0
        mitigation_recommendation = []

        if layer4_vuln:
            vuln_score += 2
            mitigation_recommendation.append("- Aktifkan rate-limiting & firewall di port terbuka rawan (NTP, DNS, dll).")
            mitigation_recommendation.append("- Gunakan ACL atau IP filtering pada port service UDP publik.")

        if layer7_vuln:
            vuln_score += 2
            mitigation_recommendation.append("- Optimalkan ukuran halaman web & kompresi konten.")
            mitigation_recommendation.append("- Implementasikan CAPTCHA atau WAF untuk membatasi bot.")

        print("\n[+] Penilaian Skor dan Mitigasi:")
        print(f"  - Skor Kerentanan DDoS: {vuln_score}/4")
        if vuln_score >= 3:
            print("  [!] Risiko tinggi terhadap serangan DDoS.")
        elif vuln_score == 2:
            print("  [!] Risiko sedang terhadap serangan DDoS.")
        else:
            print("  [OK] Risiko rendah terhadap serangan DDoS.")

        if mitigation_recommendation:
            print("\n[+] Rekomendasi Mitigasi:")
            for item in mitigation_recommendation:
                print(f"  {item}")
        else:
            print("[OK] Tidak ada rekomendasi khusus. Sistem relatif aman.")

    else:
        if cdn == "None Detected":
            score += 1
            report_lines.append("- Tidak menggunakan CDN (rentan Layer 7).")
        if "Not Detected" in firewall:
            score += 1
            report_lines.append("- Tidak terdeteksi firewall (tidak ada proteksi Layer 4/7).")
        if ttl and ttl < 300:
            score += 1
            report_lines.append("- TTL DNS rendah (bisa rawan DNS flood).")
        if resp_time and resp_time > 2:
            score += 1
            report_lines.append("- Respon lambat (bisa overload dari HTTP flood).")

    analysis_summary = "\n\n[+] ANALYSIS:\n"
    analysis_summary += f"  - Proteksi CDN terdeteksi  : {cdn if cdn != 'None Detected' else 'Tidak terdeteksi'}\n"
    analysis_summary += f"  - Firewall terdeteksi      : {', '.join(firewall) if firewall else 'Tidak terdeteksi'}\n"
    analysis_summary += f"  - DNS TTL                  : {ttl if ttl else 'Unknown'}\n"
    analysis_summary += f"  - Waktu Respon Server      : {f'{resp_time} detik' if resp_time else 'Timeout'}\n"

    if mode == "passive":
        analysis_summary += "\n[+] Evaluasi Kerentanan DDoS (mode passive):\n"
        if score >= 3:
            analysis_summary += "[!] POTENSI KERENTANAN TINGGI terhadap DDoS.\n"
        elif score == 2:
            analysis_summary += "[!] POTENSI KERENTANAN SEDANG terhadap DDoS.\n"
        else:
            analysis_summary += "[OK] Tidak ditemukan indikasi kuat kerentanan terhadap DDoS.\n"

    else:
        analysis_summary += "\n[+] Evaluasi Kerentanan DDoS (mode aggressive):\n"
        if layer4_vuln:
            analysis_summary += "[!] Target memiliki port terbuka rawan Layer 4 amplification (NTP/DNS/SSDP/etc).\n"
        else:
            analysis_summary += "[OK] Tidak ada port amplification Layer 4 umum yang terbuka.\n"

        if layer7_vuln:
            analysis_summary += "[!] Halaman besar (>1MB), berpotensi rentan terhadap Layer 7 HTTP Flood.\n"
        else:
            analysis_summary += "[OK] Ukuran halaman masih wajar untuk Layer 7.\n"

    print(analysis_summary)
    report_lines.append(analysis_summary)
    report_data = "\n".join(report_lines)
    save_report(report_data, domain)

if __name__ == "__main__":
    banner()
    target = input("Masukkan domain target (tanpa http/https): ").strip()

    print("\nPilih mode scan:")
    print("  [1] Passive (aman, tidak menyerang)")
    print("  [2] Aggressive (dengan stress test & port scan)")
    mode_input = input("Masukkan pilihan (1/2): ").strip()

    mode = "aggressive" if mode_input == "2" else "passive"
    analyze(target, mode)
