#!/usr/bin/env python3
# waf_detect.py — simple WAF detection tool
# Gunakan hanya untuk tujuan edukasi & keamanan yang sah.

import sys
import re
import urllib.parse

# === Cek dependensi ===
try:
    import requests
    from colorama import init as colorama_init, Fore, Style
    colorama_init(autoreset=True)
except ImportError:
    print("Harap instal dependensi dulu:\n  pip install requests colorama\n")
    sys.exit(1)

# === User-Agent aman ===
SAFE_UA = "WAF-Detect/1.0 (authorized-testing-only)"

# === Daftar tanda WAF umum ===
WAF_SIGS = {
    "Cloudflare": {
        "headers": [r"cloudflare", r"__cfduid", r"cf-ray"],
        "body": [r"Attention Required! \| Cloudflare"],
    },
    "Sucuri": {
        "headers": [r"x-sucuri-id", r"sucuri"],
        "body": [r"Sucuri WebSite Firewall"],
    },
    "Incapsula (Imperva)": {
        "headers": [r"incap_ses_", r"visid_incap_", r"Incapsula"],
        "body": [r"Incapsula incident ID"],
    },
    "AWS / CloudFront": {
        "headers": [r"cloudfront", r"x-amz-cf-id"],
        "body": [],
    },
    "F5 BIG-IP / ASM": {
        "headers": [r"BIG-IP", r"F5", r"TS[0-9A-Za-z_=-]+"],
        "body": [r"BIG-IP", r"F5 Networks"],
    }
}

# === Banner merah ===
def banner():
    red = Fore.RED
    yellow = Fore.YELLOW
    reset = Style.RESET_ALL
    print()
    print(f"{red}{'='*50}{reset}")
    print(f"{red}##{' ' * 13}FIREWALL DETECTION{' ' * 13}##{reset}")
    print(f"{red}{'='*50}{reset}")
    print(f"{yellow}{' ' * 17}Create by Mr.X{reset}\n")

# === Normalisasi URL ===
def normalize(url):
    url = url.strip()
    if not url:
        raise ValueError("URL kosong")
    if not re.match(r"^https?://", url):
        url = "http://" + url
    p = urllib.parse.urlparse(url)
    if not p.netloc:
        raise ValueError("URL tidak valid")
    return urllib.parse.urlunparse(p._replace(fragment=""))

# === Ambil respon dari target ===
def fetch(url, timeout=8):
    headers = {"User-Agent": SAFE_UA}
    try:
        r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True, verify=True)
    except requests.exceptions.SSLError:
        r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True, verify=False)
    return r

# === Deteksi WAF ===
def detect_waf(resp_text, resp_headers):
    found = {}
    lower_headers = {k.lower(): v for k, v in resp_headers.items()}
    text = resp_text or ""
    for name, pats in WAF_SIGS.items():
        matches = []
        for hpat in pats["headers"]:
            for hk, hv in lower_headers.items():
                if re.search(hpat, hk, re.I) or re.search(hpat, hv, re.I):
                    matches.append(f"Header match: {hk}: {hv}")
        for bpat in pats["body"]:
            m = re.search(bpat, text, re.I)
            if m:
                snippet = text[m.start():m.start()+80].replace("\n", " ")
                matches.append(f"Body snippet: {snippet}...")
        if matches:
            found[name] = matches
    return found

# === Tampilkan hasil ===
def print_results(url, resp, findings):
    print(f"{Fore.CYAN}Target:{Style.RESET_ALL} {url}")
    print(f"{Fore.CYAN}Status:{Style.RESET_ALL} {resp.status_code}")
    print(f"{Fore.CYAN}Final URL:{Style.RESET_ALL} {resp.url}\n")

    if findings:
        print(f"{Fore.RED}Possible WAF(s) detected:{Style.RESET_ALL}")
        for waf, notes in findings.items():
            print(f" - {Fore.YELLOW}{waf}{Style.RESET_ALL}")
        print(f"\n{Fore.GREEN}Website ini terlindungi firewall{Style.RESET_ALL}\n")
    else:
        print(f"{Fore.RED}Website ini tidak terlindungi firewall{Style.RESET_ALL}\n")

# === Mode interaktif ===
def interactive(initial=None):
    while True:
        try:
            if initial:
                inp = initial
                initial = None
            else:
                inp = input(f"{Fore.YELLOW}Masukkan website target (atau ketik 'exit'): {Style.RESET_ALL}").strip()
            if not inp:
                continue
            if inp.lower() in ("exit", "quit", "q"):
                print("Keluar dari program.")
                return
            url = normalize(inp)
        except Exception as e:
            print(f"{Fore.RED}Error URL:{Style.RESET_ALL} {e}")
            continue

        banner()
        try:
            resp = fetch(url)
        except Exception as e:
            print(f"{Fore.RED}Gagal mengambil data:{Style.RESET_ALL} {e}\n")
            continue

        findings = detect_waf(resp.text, resp.headers)
        print_results(url, resp, findings)

# === Entry Point ===
if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            target = normalize(sys.argv[1])
        except Exception as e:
            print("URL invalid:", e)
            sys.exit(1)
        banner()
        try:
            resp = fetch(target)
        except Exception as e:
            print("Gagal mengambil data:", e)
            sys.exit(1)
        findings = detect_waf(resp.text, resp.headers)
        print_results(target, resp, findings)
    else:
        banner()
        interactive()
